#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tests for Layer 1 (collections) and Layer 2 (truth)."""

from deed_primitives import DeedValue, DomainExit, DomainExitError, TruthValue, is_exit
from deed_collections import DeedList, DeedDict, DeedSet
import deed_truth as DT

passed = 0
failed = []


def ck(name, cond):
    global passed
    if cond:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed.append(name)
        print(f"  FAIL  {name}")


def raises_exit(fn):
    try:
        fn(); return False
    except DomainExitError:
        return True


print("=" * 70)
print("  LAYER 1 + 2 TEST")
print("=" * 70)

# --- DeedList ---
dl = DeedList()
ck("empty-but-real list: in domain", dl.in_domain)
ck("empty-but-real list: has_elements False", dl.has_elements() is False)
ck("empty-but-real list: count is floor not 0", dl.count().value == 1.0)
ck("list rejects None", raises_exit(lambda: dl.append(None)))
dl.append("a"); dl.append("b")
ck("list count after 2 appends", dl.count().value == 2.0)
ck("list out-of-range get returns DomainExit", is_exit(dl.get(99)))
ck("list [] out-of-range raises", raises_exit(lambda: dl[99]))
dl.exit_domain()
ck("exited list raises on query", raises_exit(lambda: dl.count()))
ck("exited list repr", repr(dl) == "DeedList(EXITED)")

# --- DeedDict: the handoff test 5 (miss returns DomainExit not None) ---
dd = DeedDict()
ck("dict miss returns DomainExit (NOT None)", is_exit(dd.get("nope")))
ck("dict miss is not None", dd.get("nope") is not None)
dd.set("k", 7)
ck("dict get hit", dd.get("k") == 7)
ck("dict rejects None value", raises_exit(lambda: dd.set("x", None)))
ck("dict rejects None key", raises_exit(lambda: dd.set(None, 1)))
ck("dict [] miss raises", raises_exit(lambda: dd["nope"]))
ck("dict empty-but-real count is floor", DeedDict().count().value == 1.0)

# --- DeedSet ---
ds = DeedSet(["x", "y"])
ck("set has member", ds.has("x"))
ck("set rejects None", raises_exit(lambda: ds.add(None)))
ck("set intersection", ds.intersection(DeedSet(["y", "z"])).has("y"))

# --- Truth engine ---
T, F, U, P = TruthValue.TRUE, TruthValue.FALSE, TruthValue.UNKNOWN, TruthValue.PROBE
ck("combine_truths all true = TRUE", DT.combine_truths([T, T, T]) is T)
ck("combine_truths with false = FALSE", DT.combine_truths([T, F, T]) is F)
ck("combine_truths with probe propagates", DT.combine_truths([T, P, T]) is P)
ck("combine_truths empty = UNKNOWN", DT.combine_truths([]) is U)
ck("any_true with one true = TRUE", DT.any_true([F, F, T]) is T)
ck("probe_required(PROBE)", DT.probe_required(P))
ck("definite(TRUE)", DT.definite(T) and not DT.definite(U))

# weighted_truth
wr = DT.weighted_truth([(T, DeedValue(80)), (F, DeedValue(20))])
ck("weighted_truth true-dominant = TRUE", wr.truth is T)
ck("weighted_truth confidence is floored DeedValue", wr.confidence.value >= 1.0)
wp = DT.weighted_truth([(T, DeedValue(80)), (P, DeedValue(1))])
ck("weighted_truth with any PROBE = PROBE", wp.truth is P)
wb = DT.weighted_truth([(T, DeedValue(50)), (F, DeedValue(50))])
ck("weighted_truth balanced = UNKNOWN", wb.truth is U)

# sigma_k
nmax = DeedValue(100)
s0 = DT.sigma_k(0, nmax)
s50 = DT.sigma_k(50, nmax)
s999 = DT.sigma_k(999, nmax)
ck("sigma_k at k=0 is highest", s0.value > s50.value)
ck("sigma_k decreases with distance", s50.value > 1.0)
ck("sigma_k floors, never 0, at huge k", s999.value == 1.0 and s999.value != 0)
ck("sigma_k negative k raises", raises_exit(lambda: DT.sigma_k(-1, nmax)))

# score_to_truth with probe band
ck("score above band = TRUE", DT.score_to_truth(DeedValue(90), (40.0, 60.0)) is T)
ck("score in band = PROBE", DT.score_to_truth(DeedValue(50), (40.0, 60.0)) is P)
ck("score below band = FALSE", DT.score_to_truth(DeedValue(10), (40.0, 60.0)) is F)

print("=" * 70)
total = passed + len(failed)
print(f"  {passed}/{total} passed")
if failed:
    for f_ in failed:
        print(f"    FAILED: {f_}")
else:
    print("  LAYERS 1+2 SOUND")
print("=" * 70)
import sys
sys.exit(0 if not failed else 1)
