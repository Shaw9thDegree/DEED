#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tests for deed_kernel.py — the three-category separation engine."""

from deed_primitives import TruthValue, DomainExitError, is_exit, DomainExit
from deed_kernel import (
    Category, Constant, SystemRule, DomainRule,
    ConstantStore, RuleStore, DeedKernel, ProofObligation,
)

passed = 0
failed = []

def ck(name, cond):
    global passed
    if cond:
        passed += 1; print(f"  PASS  {name}")
    else:
        failed.append(name); print(f"  FAIL  {name}")

def raises_exit(fn):
    try:
        fn(); return False
    except DomainExitError:
        return True

print("=" * 70)
print("  DEED KERNEL TEST — three-category separation")
print("=" * 70)

# --- Constants are TRUE by constancy, write-once, immutable ---
c = Constant("D49.1", "every quantity is an integer multiple of epsilon", ["E(E)=E", "C=N!=0"], 49)
ck("constant is TRUE by constancy", c.truth is TruthValue.TRUE)
ck("constant carries its proof trail", "E(E)=E" in c.trail)
ck("constant is immutable (cannot reassign statement)",
   raises_exit(lambda: setattr(c, "_statement", "tampered")))

# --- ConstantStore is write-once ---
store = ConstantStore()
ck("commit new constant succeeds", store.add(c).truth is TruthValue.TRUE)
ck("re-adding same statement is idempotent TRUE",
   store.add(Constant("D49.1", "every quantity is an integer multiple of epsilon", ["E(E)=E"], 49)).truth is TruthValue.TRUE)
ck("redefining same id with different statement is REJECTED",
   store.add(Constant("D49.1", "DIFFERENT", ["x"], 49)).truth is TruthValue.FALSE)
ck("store miss returns DomainExit not None", is_exit(store.get("nope")))

# --- The single governing rule + axiom-tamper handling ---
k = DeedKernel()
k.install_governing_rule()
ck("SYSTEM_SUPREME_001 installed", any(r.id == "SYSTEM_SUPREME_001" for r in k.rules.system_rules()))
# seed a constant and mark stable
k.constants.add(Constant("C0", "C=N!=0", ["E(E)=E"], 49))
k.mark_stable()
tamper = k.attempt_rule_on_axiom("SOME_RULE", "C0")
ck("rule attempting to alter axiom = PROBE (axiom-tamper)", tamper.truth is TruthValue.PROBE)
ck("axiom-tamper attempt notes the revert", "Reverted" in tamper.notes)
ck("the targeted constant is UNCHANGED after tamper attempt",
   k.constants.get("C0").statement == "C=N!=0")

# --- Shae's two-gate autonomous constant authoring ---
# Gate 1 fail: no trail to first principles
no_trail = ProofObligation("some new claim", [])
ck("proof gate fails with empty trail",
   k.propose_constant("NEW1", no_trail).truth is TruthValue.FALSE)

# Both gates pass: grounded + non-contradictory
good = ProofObligation("the vacuum energy is at least epsilon", ["C=N!=0", "E(E)=E"])
res = k.propose_constant("D34.1", good, domain_id=34)
ck("constant commits when proof + non-contradiction pass", res.truth is TruthValue.TRUE)
ck("committed constant is now in the store", k.constants.get("D34.1").truth is TruthValue.TRUE)

# Gate 2 fail: direct contradiction with a prior constant
contra = ProofObligation("C=N=0", ["E(E)=E"])  # negates the non-zero floor
ck("non-contradiction gate blocks a constant that challenges a prior constant",
   k.propose_constant("BAD", contra).truth is TruthValue.FALSE)

# --- A constant may never be a system rule (self-reference detection) ---
ck("self-referential 'DEED is complete' flagged as system rule, not constant",
   k.reject_constant_if_system_rule("DEED is complete within its confirmed domain"))
ck("genuine math statement NOT flagged as system rule",
   not k.reject_constant_if_system_rule("every prime greater than epsilon has two divisors"))

# --- Rules: system vs domain, revisable (procedures, not axioms) ---
rs = RuleStore()
sr = SystemRule("SR1", "procedures must log their accessor")
ck("system rule category", sr.category is Category.SYSTEM_RULE)
ck("system rule is revisable (rules touch procedures)", sr.revise("updated").truth is TruthValue.TRUE)
dr = DomainRule("DR1", "domain 41 procedures encrypt before persist", 41)
ck("domain rule carries its scope", dr.domain_id == 41)
ck("domain rule category", dr.category is Category.DOMAIN_RULE)

print("=" * 70)
total = passed + len(failed)
print(f"  {passed}/{total} passed")
if failed:
    for f_ in failed: print(f"    FAILED: {f_}")
else:
    print("  KERNEL SOUND — constants/rules separated, axioms untouchable")
print("=" * 70)
import sys
sys.exit(0 if not failed else 1)
