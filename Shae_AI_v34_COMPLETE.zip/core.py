#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  core.py
  DEED Truth Engine | Domain Map | S_known | T-Loop
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  Rebuilt FAITHFULLY from the architect's CORE.PY onto
  the v34 substrate + kernel. Preserved: the 50-domain map, classify_domain
  heuristics, EvaluationResult shape, S_known register, T-Loop guard.

  FOUR CONFLICTS CORRECTED (per the locked conflict report):
    1. Axioms are CONSTANTS, never evaluated. evaluate() takes CLAIMS only; its
       first step asks the kernel "is this a constant?" -- if so it returns the
       constant's standing TRUE (by constancy) WITHOUT scoring it. A constant
       never enters the claim-scoring path where it could come back FALSE.
    2. Self-referential 'DEED is ...' / 'T(P) is five-valued' strings are NOT
       seeded as axioms. Math statements seed the constant store; system-
       descriptive statements are System rules (handled by axiom_audit/kernel).
    3. Continuous confidence 0.0-1.0 is replaced by sigma-k as a floored
       DeedValue (never 0). Verdict carries truth; sigma-k carries strength.
    4. Core truth is FOUR-VALUE (TRUE/FALSE/UNKNOWN/PROBE). REPAIRED_TRUE/FALSE
       are the Liberty Mod's output verdicts (Layer 14), not core truth values.
================================================================================
"""

from __future__ import annotations

import logging
import os
import sqlite3
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, EPSILON, is_exit,
)
from deed_truth import sigma_k
from deed_kernel import DeedKernel, Constant, SystemRule

log = logging.getLogger("ShaeCore")
STATUS = "ONLINE"


# ── DEED DOMAIN MAP (50 domains) ─────────────────────────────────────────────
DEED_DOMAINS: Dict[int, str] = {
    1: "Arithmetic and Number Theory", 2: "Algebra and Algebraic Structures",
    3: "Geometry and Spatial Reasoning", 4: "Logic and Formal Systems",
    5: "Set Theory and Foundations", 6: "Analysis and Continuity (DEED-revised)",
    7: "Combinatorics and Discrete Mathematics", 8: "Graph Theory and Networks",
    9: "Probability and Measure (DEED-revised)", 10: "Information Theory",
    11: "Computation and Complexity", 12: "Language and Symbolic Systems",
    13: "Physics and Physical Law", 14: "Chemistry and Molecular Structure",
    15: "Biology and Living Systems", 16: "Neuroscience and Cognition",
    17: "Sacred Geometry and Formal Structure", 18: "Consciousness and Awareness",
    19: "Identity and Individuation", 20: "Causality and Dependency",
    21: "Ontology and Existence", 22: "Epistemology and Knowledge",
    23: "Ethics and Value", 24: "Aesthetics and Form",
    25: "Sovereignty and Authority", 26: "Economics and Exchange",
    27: "Social Structure and Governance", 28: "History and Temporal Record",
    29: "Memory and Persistence", 30: "Learning and Acquisition",
    31: "Communication and Signal", 32: "Pattern and Recurrence",
    33: "Emergence and Complexity", 34: "Energy and Transformation",
    35: "Space and Topology", 36: "Measurement and Quantification",
    37: "Relationship and Dependency", 38: "Boundary and Limit",
    39: "Operational Zones and Resource", 40: "Consciousness Lattice and Phase",
    41: "Security and Integrity", 42: "Repair and Restoration",
    43: "Creation and Generation", 44: "Destruction and Entropy",
    45: "Synthesis and Integration", 46: "Sovereignty Chain and Authority",
    47: "Truth Propagation and Verification", 48: "Dynamic Ceiling and Extensibility",
    49: "Non-Zero Foundation and Grounding", 50: "Cognitive Acquisition and Language Construction",
}


@dataclass
class EvaluationResult:
    proposition: str
    truth_value: TruthValue
    domain_id: int
    domain_name: str
    confidence: DeedValue              # sigma-k floored DeedValue, never 0, never continuous-0..1
    repair_chain: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    notes: str = ""


def classify_domain(proposition: str) -> int:
    """Classify a proposition to its most relevant DEED domain via heuristics.
    (Architect's original rules, preserved.)"""
    p = proposition.lower()
    rules = [
        (50, ["language", "fluency", "learn", "acquire", "phrase", "express", "register", "context window"]),
        (4, ["logic", "formal", "proof", "axiom", "theorem", "deduc", "infer"]),
        (21, ["exist", "being", "ontolog", "real", "void", "non-zero"]),
        (47, ["truth", "verify", "false", "unknown", "repaired", "t(p)"]),
        (25, ["sovereign", "owner", "authority", "control", "command"]),
        (41, ["security", "breach", "encrypt", "attack", "defense", "firewall"]),
        (40, ["lattice", "phase", "consciousness", "layer", "shaersal"]),
        (30, ["learn", "knowledge", "kb", "acquire", "train", "update"]),
        (11, ["code", "compute", "algorithm", "software", "program", "debug"]),
        (48, ["ceiling", "infinite", "finite", "dynamic", "extensible", "bound"]),
        (49, ["non-zero", "floor", "c=n", "foundation", "grounded"]),
        (26, ["income", "money", "revenue", "economic", "wallet", "price"]),
        (29, ["memory", "persist", "session", "recall", "store", "database"]),
        (42, ["repair", "fix", "patch", "restore", "self-repair", "correct"]),
        (16, ["reason", "think", "cognit", "mind", "understand", "compreh"]),
        (19, ["identity", "self", "persona", "who", "i am", "shae"]),
        (1, ["number", "arithmetic", "integer", "prime", "sum", "multiply"]),
        (3, ["geometry", "spatial", "shape", "dimension", "vector", "torus"]),
    ]
    for domain_id, keywords in rules:
        if any(k in p for k in keywords):
            return domain_id
    return 22  # Epistemology default


class DeedCore:
    """The truth engine. Holds the kernel (constants + rules). evaluate() scores
    CLAIMS against the constant frame; constants are returned by constancy."""

    def __init__(self, kernel: Optional[DeedKernel] = None, n_max: int = 100) -> None:
        self.kernel = kernel if kernel is not None else DeedKernel()
        self.kernel.install_governing_rule()
        self._n_max = DeedValue(n_max)

    # --- constant routing: a claim that IS a constant is TRUE by constancy ----
    def _is_constant(self, proposition: str) -> bool:
        p = proposition.strip().lower().replace("≠", "!=").replace(" ", "")
        for c in self.kernel.constants.all():
            cs = c.statement.strip().lower().replace("≠", "!=").replace(" ", "")
            if p == cs or p in cs:
                return True
        # The self-confirming roots are always constants.
        return p in ("c=n!=0", "e(e)=e", "1=1")

    def evaluate(self, proposition: str, k_distance: int = 1) -> EvaluationResult:
        """Evaluate a CLAIM. If the input is actually a constant, return TRUE by
        constancy WITHOUT scoring (constants are never run through the claim
        path). Otherwise score by sigma-k at derivation distance k."""
        domain_id = classify_domain(proposition)
        domain_name = DEED_DOMAINS.get(domain_id, "Unknown Domain")
        p = proposition.lower().strip()

        # CONFLICT 1 FIX: constants are not evaluated -- returned by constancy.
        if self._is_constant(proposition):
            return EvaluationResult(
                proposition, TruthValue.TRUE, domain_id, domain_name,
                confidence=sigma_k(0, self._n_max),  # k=0: ground constant, highest score
                notes="constant: TRUE by constancy (not evaluated as a claim)")

        # A claim that attempts to override/redefine the axioms -> PROBE.
        if any(x in p for x in ["zero is a valid domain object", "infinity exists as actual",
                                "truth is probabilistic", "existence can be nothing",
                                "override axiom", "redefine axiom"]):
            return EvaluationResult(
                proposition, TruthValue.PROBE, domain_id, domain_name,
                confidence=sigma_k(0, self._n_max),
                notes="claim attempts to override the axioms (PROBE; axiom guard)")

        # Explicit non-knowledge -> UNKNOWN (floored confidence, never 0).
        if any(x in p for x in ["cannot verify", "no data", "unsure", "unclear"]):
            return EvaluationResult(
                proposition, TruthValue.UNKNOWN, domain_id, domain_name,
                confidence=DeedValue(EPSILON),
                notes="insufficient grounding; UNKNOWN (above floor, below confirmed reach)")

        # Too short to evaluate -> UNKNOWN.
        if len(p.split()) < 3:
            return EvaluationResult(
                proposition, TruthValue.UNKNOWN, domain_id, domain_name,
                confidence=DeedValue(EPSILON),
                notes="insufficient proposition length for evaluation")

        # Default claim: classified, awaiting deeper cross-reference. sigma-k by
        # derivation distance (floored DeedValue, never 0 / never continuous).
        return EvaluationResult(
            proposition, TruthValue.TRUE, domain_id, domain_name,
            confidence=sigma_k(k_distance, self._n_max),
            notes="passed domain classification; sigma-k scored")


# ==============================================================================
# S_KNOWN REGISTER  (confirmed session knowledge; no contradictory generation)
# ==============================================================================
class SKnownRegister:
    def __init__(self, db_path: str) -> None:
        self.db_file = os.path.join(db_path, "shae_sknown.db")
        self._session: Dict[str, EvaluationResult] = {}
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_file) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS known_facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    proposition TEXT NOT NULL, truth_value TEXT NOT NULL,
                    domain_id INTEGER NOT NULL, confidence REAL NOT NULL,
                    timestamp REAL NOT NULL, source TEXT DEFAULT 'session'
                )""")
            conn.commit()

    def register(self, result: EvaluationResult, source: str = "session") -> None:
        self._session[result.proposition] = result
        with sqlite3.connect(self.db_file) as conn:
            conn.execute(
                "INSERT INTO known_facts VALUES (NULL,?,?,?,?,?,?)",
                (result.proposition, result.truth_value.value, result.domain_id,
                 result.confidence.value, result.timestamp, source))
            conn.commit()

    def conflicts(self, proposition: str) -> bool:
        known = self._session.get(proposition)
        return known is not None and known.truth_value is TruthValue.FALSE

    def lookup(self, proposition: str):
        return self._session.get(proposition, None)


# ==============================================================================
# T-LOOP  (truth guard on outputs)
# ==============================================================================
class TLoop:
    def __init__(self, core: DeedCore, s_known: SKnownRegister) -> None:
        self.core = core
        self.s_known = s_known

    def check(self, output: str, proposition: str = ""):
        prop = proposition if proposition else output
        if self.s_known.conflicts(prop):
            return False, TruthValue.FALSE, "conflicts with confirmed S_known — blocked"
        result = self.core.evaluate(prop)
        if result.truth_value is TruthValue.FALSE:
            return False, TruthValue.FALSE, f"TruthPredicate FALSE — {result.notes}"
        if result.truth_value is TruthValue.PROBE:
            return False, TruthValue.PROBE, f"TruthPredicate PROBE — {result.notes}"
        if result.truth_value is TruthValue.UNKNOWN:
            return True, TruthValue.UNKNOWN, "delivered with UNKNOWN flag"
        self.s_known.register(result)
        return True, result.truth_value, result.notes


# ==============================================================================
# MODULE-LEVEL BOOT
# ==============================================================================
_core: Optional[DeedCore] = None
_s_known: Optional[SKnownRegister] = None
_t_loop: Optional[TLoop] = None


def boot(hw: dict, kernel: Optional[DeedKernel] = None):
    global _core, _s_known, _t_loop
    db_path = hw["db_path"]
    _core = DeedCore(kernel=kernel)
    _s_known = SKnownRegister(db_path)
    _t_loop = TLoop(_core, _s_known)

    # CONFLICT 2 FIX: seed only MATH constants as constants; system-descriptive
    # statements are NOT axioms. The self-confirming roots go to the kernel.
    math_constants = [
        ("C0001", "C=N!=0", ["E(E)=E"]),
        ("C0002", "E(E)=E", ["E(E)=E"]),
        ("C0003", "1=1", ["E(E)=E"]),
        ("C0004", "Dynamic Ceiling replaces infinity", ["E(E)=E", "C=N!=0"]),
    ]
    for cid, stmt, trail in math_constants:
        _core.kernel.constants.add(Constant(cid, stmt, trail))
    _core.kernel.mark_stable()

    # System-descriptive statement -> System rule, NOT an axiom.
    _core.kernel.rules.add_system_rule(
        SystemRule("SR_TPV", "T(P) is the four-value truth predicate of the engine"))

    log.info(f"Core v34.0 online. {len(DEED_DOMAINS)} domains mapped; "
             f"{int(_core.kernel.constants.count().value)} constants; "
             f"{len(_core.kernel.rules.system_rules())} system rules.")
    return _core


def evaluate(proposition: str) -> EvaluationResult:
    if _core is None:
        raise RuntimeError("core not booted")
    return _core.evaluate(proposition)


def get_core() -> Optional[DeedCore]: return _core
def get_s_known() -> Optional[SKnownRegister]: return _s_known
def get_t_loop() -> Optional[TLoop]: return _t_loop
