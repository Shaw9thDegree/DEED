#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34  —  LAYER 0  —  deed_primitives.py
  THE SUBSTRATE. Built first, alone. Every layer above inherits from this.
--------------------------------------------------------------------------------
  Architect: Jarad Shaw — 9th Degree — DEED framework author.
  Ground:    C = N != 0   |   E(E) = E   |   T(P) in {TRUE,FALSE,UNKNOWN,PROBE}

  THE FOUNDATION RULE THIS FILE EXISTS TO ENFORCE
  ------------------------------------------------
  In DEED, the ABSENCE of a thing and the SMALLNESS of a thing are different
  categories. Standard math collapses them onto one continuum where you can
  approach 0 in the limit. DEED separates them:

      * A small value lives AT or NEAR the floor (epsilon, the "1" --
        the smallest state capable of measuring or counting). It still EXISTS.
      * An absence is DOMAIN EXIT -- not a value at all. The question dissolves.

  Python's substrate forbids this by default: 0 is the default of every numeric
  type, None is the default miss-return, [] / "" / 0 are all falsy. Every prior
  Shae (v23..v33.x) was built on that substrate and therefore smuggled in the
  exact value DEED's first axiom forbids. This file replaces the substrate.

  THE EPSILON CONVENTION (confirmed by the architect, v34)
  --------------------------------------------------------
  epsilon is the smallest state capable of measuring or counting. We call it
  the floor "1" because it is the minimum countable unit -- the bottom rung of
  measurement itself, not an arbitrarily small float. The floor is ABSOLUTELY
  FINITE and integer-anchored. It is per-domain configurable UPWARD, but it
  never vanishes toward 0 and a domain value never reaches 0 or infinity.
  The system is hybrid: the floor is fixed and finite; the ceiling is dynamic
  (n ranges min -> max, bounded, expandable). This is C = N != 0 made literal.
================================================================================
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Any, Callable, Generic, List, Optional, TypeVar, Union


__all__ = [
    "EPSILON",
    "DomainExit",
    "DomainExitError",
    "DeedValue",
    "DynamicCeiling",
    "TruthValue",
    "DeedResult",
    "Maybe",
    "is_exit",
    "require_value",
]


# ==============================================================================
# THE FLOOR CONSTANT  —  IMMUTABLE. ABSOLUTELY UNCRACKABLE.
# ------------------------------------------------------------------------------
# epsilon = the smallest measurable/countable state. The "1" of DEED.
#
# The system is HYBRID but the two halves are not symmetric:
#   * THE SKY (DynamicCeiling) is the recorded, expanding half. It rises as
#     confirmation rises. This is the practical infinite horizon.
#   * THE FLOOR (this constant) is the FIXED half. It does NOT move. It is not
#     a default, not a per-domain setting, not raisable, not lowerable. There
#     is exactly ONE floor, system-wide, and it is C = N != 0 made literal.
#
# Why immutable and not "configurable upward": if any code path can pass a
# floor in, that same surface can pass a floor toward 0, and the first axiom of
# the entire system becomes defeatable from a config argument. The floor is the
# one thing nothing is allowed to move. The sky moves. The floor never does.
# ==============================================================================
EPSILON: float = 1.0  # immutable. Do not parameterize. Do not override. The "1".


# ==============================================================================
# DOMAIN EXIT
# ------------------------------------------------------------------------------
# Both an exception (raised when an operation would PRODUCE a forbidden value)
# and a singleton sentinel (RETURNED where Python would have returned None/0).
#
# Identity is the canonical check:   result is DomainExit
# Equality is meaningless on purpose: DomainExit == anything  -> False,
# including DomainExit == DomainExit -> False. There is no "an absence equals
# an absence"; an absence is not a value, so it compares equal to nothing.
# ==============================================================================
class DomainExitError(Exception):
    """Raised when an operation would produce 0, None, infinity, or undefined.

    The kernel that catches this decides whether to clamp to the floor, repair,
    or escalate. Primitives never silently swallow it.
    """

    def __init__(self, reason: str = "operation left the domain") -> None:
        super().__init__(reason)
        self.reason = reason


class _DomainExitSentinel:
    """Singleton 'the question dissolved' marker. Returned, not a value.

    Use `x is DomainExit` to test. Never truthy, never equal to anything.
    """

    _instance: Optional["_DomainExitSentinel"] = None

    def __new__(cls) -> "_DomainExitSentinel":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __bool__(self) -> bool:
        # An absence is not "false" -- in DEED falsehood is a truth value and
        # this is the absence of a value entirely. But Python forces a bool
        # answer for `if x:`. We return False so that an accidental truthiness
        # check cannot mistake an absence for a present value. Correct code
        # must still use `is DomainExit`, never `if x:`.
        return False

    def __eq__(self, other: object) -> bool:
        return False  # equal to nothing, including itself

    def __ne__(self, other: object) -> bool:
        return True

    def __hash__(self) -> int:
        # Stable identity hash so it can key a DeedDict as the miss-marker.
        return id(self)

    def __repr__(self) -> str:
        return "DomainExit"

    # Any arithmetic on an absence is itself an absence-producing error.
    def _forbid(self, *_: Any) -> "Any":
        raise DomainExitError("arithmetic on DomainExit is undefined")

    __add__ = __sub__ = __mul__ = __truediv__ = _forbid
    __radd__ = __rsub__ = __rmul__ = __rtruediv__ = _forbid


DomainExit: _DomainExitSentinel = _DomainExitSentinel()


def is_exit(x: object) -> bool:
    """Canonical absence check. True iff x is the Domain Exit sentinel."""
    return x is DomainExit


# ==============================================================================
# DEED VALUE
# ------------------------------------------------------------------------------
# A scalar that cannot hold 0, None, or infinity. The floor is finite and
# integer-anchored (default EPSILON = 1.0, configurable upward per-domain).
#
#   * DeedValue(0) / DeedValue(None) -> DomainExitError at construction.
#   * subtraction that would reach the floor or below CLAMPS to floor and
#     records the clamp in a metadata trail (the value still EXISTS at floor;
#     it did not become 0).
#   * division by a sub-floor divisor -> DomainExitError (never ZeroDivision).
#   * comparison with literal 0 -> always False (0 is not in the domain).
#   * __bool__ -> always True (a DeedValue exists; existence is truthful).
#     Python truthiness is replaced by explicit TruthValue checks elsewhere.
# ==============================================================================
class DeedValue:
    # No per-instance floor. There is ONE floor: EPSILON, system-wide, immutable.
    # The floor is the entrance to existence: at or above it there is mass,
    # energy, space -- a definable, perceivable state. Below it there is none of
    # that. It is literally non-existence, and DEED covers existence, so below
    # the floor is outside the system's scope entirely. There is nothing there
    # to clamp, record, or perceive -- only Domain Exit marks that a question
    # left existence.
    __slots__ = ("_v",)

    def __init__(
        self,
        value: Union[int, float, "DeedValue"],
    ) -> None:
        # NOTE: there is deliberately no `floor=` parameter. The floor is the
        # immutable system constant EPSILON. Nothing passes a floor in, because
        # any surface that accepts a floor can be handed a floor toward 0, and
        # the first axiom of the system becomes defeatable from an argument.
        if value is None:
            raise DomainExitError("DeedValue cannot be None (absence is not a value)")
        if isinstance(value, _DomainExitSentinel) or value is DomainExit:
            raise DomainExitError("DeedValue cannot be Domain Exit")
        if isinstance(value, DeedValue):
            value = value._v

        v = float(value)
        if math.isnan(v):
            raise DomainExitError("DeedValue cannot be NaN")
        if math.isinf(v):
            raise DomainExitError("DeedValue cannot be infinite (use DynamicCeiling)")
        if v == 0.0:
            raise DomainExitError("DeedValue cannot be 0 (C = N != 0)")

        if abs(v) < EPSILON:
            # Below the floor = no mass, no energy, no space, no definable state.
            # It is non-existence, which DEED does not cover. There is no value
            # to construct here; the question is outside existence. Domain Exit.
            raise DomainExitError(
                f"value {v} is below the floor (EPSILON={EPSILON}) — "
                "non-existence, outside DEED's scope, not a value"
            )
        self._v: float = v

    # --- accessors -----------------------------------------------------------
    @property
    def value(self) -> float:
        return self._v

    @property
    def floor(self) -> float:
        # Read-only view of the one immutable system floor (entrance to existence).
        return EPSILON

    # --- arithmetic ----------------------------------------------------------
    def _coerce(self, other: Any) -> float:
        if isinstance(other, DeedValue):
            return other._v
        if other is None or other is DomainExit:
            raise DomainExitError("arithmetic with absence is undefined")
        return float(other)

    def _make(self, raw: float) -> Union["DeedValue", "_DomainExitSentinel"]:
        # The floor is the barrier of existence. A result at or above the floor
        # is a definable state and lives. A result below the floor is not a
        # small value -- it is the region of what can never be and never was.
        # There is nothing there to return: the value goes dark. Domain Exit.
        if math.isinf(raw):
            raise DomainExitError("arithmetic produced infinity")
        if abs(raw) < EPSILON:
            return DomainExit  # what did exist, dies; below the floor is not a state
        return DeedValue(raw)

    def __add__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self._make(self._v + self._coerce(other))

    def __radd__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self.__add__(other)

    def __sub__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        # 1 - 1 does not return the floor. It crosses under the floor: it dies.
        return self._make(self._v - self._coerce(other))

    def __rsub__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self._make(self._coerce(other) - self._v)

    def __mul__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self._make(self._v * self._coerce(other))

    def __rmul__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self.__mul__(other)

    def __truediv__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        divisor = self._coerce(other)
        if abs(divisor) < EPSILON:
            raise DomainExitError("division by sub-floor divisor (would cross the floor)")
        return self._make(self._v / divisor)

    def __rtruediv__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        # self._v is always >= EPSILON by construction, so this never trips,
        # but the guard documents the invariant: no division across the floor.
        if abs(self._v) < EPSILON:
            raise DomainExitError("division by sub-floor divisor")
        return self._make(self._coerce(other) / self._v)

    def __pow__(self, other: Any) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self._make(self._v ** self._coerce(other))

    def __neg__(self) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self._make(-self._v)

    def __abs__(self) -> Union["DeedValue", "_DomainExitSentinel"]:
        return self._make(abs(self._v))

    # --- comparison ----------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if isinstance(other, (int, float)) and not isinstance(other, bool):
            if other == 0:
                return False  # 0 is not in the domain; nothing equals it
            return self._v == float(other)
        if isinstance(other, DeedValue):
            return self._v == other._v
        return NotImplemented

    def __ne__(self, other: object) -> bool:
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __lt__(self, other: Any) -> bool:
        return self._v < self._coerce(other)

    def __le__(self, other: Any) -> bool:
        return self._v <= self._coerce(other)

    def __gt__(self, other: Any) -> bool:
        return self._v > self._coerce(other)

    def __ge__(self, other: Any) -> bool:
        return self._v >= self._coerce(other)

    def __hash__(self) -> int:
        return hash(self._v)

    # --- existential truthiness ---------------------------------------------
    def __bool__(self) -> bool:
        # A DeedValue always exists, therefore it is existentially truthful.
        # This deliberately defeats Python's "0 is falsy" trap: there is no
        # 0 here to be falsy. Logical decisions must use TruthValue, not this.
        return True

    def __float__(self) -> float:
        return self._v

    def __int__(self) -> int:
        return int(self._v)

    def __repr__(self) -> str:
        return f"DeedValue({self._v:g}, floor={EPSILON:g})"


# ==============================================================================
# DYNAMIC CEILING  (the sky — a RECORDER, not a wall)
# ------------------------------------------------------------------------------
# There is no real ceiling. The floor is the only barrier. The "sky" does not
# cap anything -- it RECORDS how far reach has been taken: Ceiling(DEED, t) =
# max_confirmed(entity, t). It is the high-water mark of confirmed reach and a
# trail of how that reach grew.
#
# DEED's perception is individual AND universal: the trail is this entity's
# reach (individual), while every confirmed step is a constant and the trail of
# constants leads back to first principles -- C = N != 0 (universal). The trail
# IS the proof. That is how a proper formal system scopes: not by measuring and
# possibly being wrong, but by recording a derivation path of constants.
#
# Therefore the sky NEVER blocks and NEVER rejects a value for being "too high":
# there is no too-high. A value at or below confirmed reach is TRUE (confirmed).
# A value beyond confirmed reach is UNKNOWN (above the sky, not yet confirmed --
# never FALSE). Recording a higher value simply raises the reach.
# ==============================================================================
class DynamicCeiling:
    __slots__ = ("_reach", "_trail")

    def __init__(self, initial: Union[int, float, DeedValue]) -> None:
        dv = initial if isinstance(initial, DeedValue) else DeedValue(initial)
        self._reach: DeedValue = dv
        # The trail: every confirmed reach value, in order. This is the proof
        # path -- individual to this entity, built from universal constants.
        self._trail: List[float] = [dv.value]

    @property
    def reach(self) -> DeedValue:
        """Current high-water mark of confirmed reach."""
        return self._reach

    # Backward-compatible alias; the sky's value is the confirmed reach.
    @property
    def ceiling(self) -> DeedValue:
        return self._reach

    @property
    def trail(self) -> List[float]:
        """The recorded derivation path of how reach grew. The proof trail."""
        return list(self._trail)

    def record(self, v: Union[int, float, DeedValue]) -> DeedResult:
        """Record reach. NEVER blocks. If v exceeds current reach, reach rises
        and the step is appended to the trail. A value at/below reach is already
        confirmed. The sky only ever grows."""
        nv = v if isinstance(v, DeedValue) else DeedValue(v)
        if nv.value > self._reach.value:
            self._reach = nv
            self._trail.append(nv.value)
            return DeedResult(truth=TruthValue.TRUE, value=nv,
                              notes="reach extended; trail recorded")
        # Already within confirmed reach -- confirmed, no change to the sky.
        return DeedResult(truth=TruthValue.TRUE, value=self._reach,
                          notes="value within confirmed reach")

    def classify(self, v: Union[int, float, DeedValue]) -> DeedResult:
        """Classify a value against confirmed reach WITHOUT blocking it.
        Within reach -> TRUE (confirmed). Beyond reach -> UNKNOWN (above the
        sky; not yet confirmed, never FALSE). The sky does not forbid."""
        val = v.value if isinstance(v, DeedValue) else float(v)
        if val <= self._reach.value:
            return DeedResult(truth=TruthValue.TRUE, value=DeedValue(val),
                              notes="within confirmed reach")
        return DeedResult(truth=TruthValue.UNKNOWN, value=DeedValue(val),
                          notes="beyond confirmed reach (above the sky; unconfirmed, not false)")

    def __repr__(self) -> str:
        return f"DynamicCeiling(reach={self._reach.value:g}, trail_len={len(self._trail)})"


# ==============================================================================
# TRUTH VALUE  (four-value T(P))
# ------------------------------------------------------------------------------
# Not Python booleans. `if truth_value:` is forbidden -- it raises. Callers
# MUST compare explicitly: `if tv is TruthValue.TRUE`.
# Operators are Kleene three-valued logic extended with PROBE = "investigate
# further", which propagates through any operation (it is neither true nor
# false until probed, and refuses to be silently resolved).
# ==============================================================================
class TruthValue(Enum):
    TRUE = "TRUE"
    FALSE = "FALSE"
    UNKNOWN = "UNKNOWN"
    PROBE = "PROBE"

    def __bool__(self) -> bool:
        # Forbid `if truth_value:` -- forces explicit `is TruthValue.TRUE`.
        raise DomainExitError(
            "TruthValue has no Python-bool coercion; compare with `is TruthValue.TRUE`"
        )

    # --- four-value operators ------------------------------------------------
    def NOT(self) -> "TruthValue":
        return {
            TruthValue.TRUE: TruthValue.FALSE,
            TruthValue.FALSE: TruthValue.TRUE,
            TruthValue.UNKNOWN: TruthValue.UNKNOWN,
            TruthValue.PROBE: TruthValue.PROBE,
        }[self]

    def AND(self, other: "TruthValue") -> "TruthValue":
        # PROBE dominates everything except a hard FALSE (FALSE short-circuits,
        # since one false conjunct makes the whole false regardless of probing).
        if self is TruthValue.FALSE or other is TruthValue.FALSE:
            return TruthValue.FALSE
        if self is TruthValue.PROBE or other is TruthValue.PROBE:
            return TruthValue.PROBE
        if self is TruthValue.UNKNOWN or other is TruthValue.UNKNOWN:
            return TruthValue.UNKNOWN
        return TruthValue.TRUE

    def OR(self, other: "TruthValue") -> "TruthValue":
        # TRUE short-circuits (one true disjunct makes the whole true).
        if self is TruthValue.TRUE or other is TruthValue.TRUE:
            return TruthValue.TRUE
        if self is TruthValue.PROBE or other is TruthValue.PROBE:
            return TruthValue.PROBE
        if self is TruthValue.UNKNOWN or other is TruthValue.UNKNOWN:
            return TruthValue.UNKNOWN
        return TruthValue.FALSE

    def IMPLIES(self, other: "TruthValue") -> "TruthValue":
        # P -> Q  ==  (NOT P) OR Q, with PROBE propagation preserved.
        return self.NOT().OR(other)

    def BICONDITIONAL(self, other: "TruthValue") -> "TruthValue":
        if self is TruthValue.PROBE or other is TruthValue.PROBE:
            return TruthValue.PROBE
        if self is TruthValue.UNKNOWN or other is TruthValue.UNKNOWN:
            return TruthValue.UNKNOWN
        return TruthValue.TRUE if self is other else TruthValue.FALSE

    @property
    def is_definite(self) -> bool:
        return self is TruthValue.TRUE or self is TruthValue.FALSE

    @property
    def needs_probe(self) -> bool:
        return self is TruthValue.PROBE


# ==============================================================================
# DEED RESULT  (standard return type for any DEED-aware function)
# ------------------------------------------------------------------------------
# Replaces "return value or None" entirely. Pattern-match-friendly so callers
# must handle all four truth states. value is either a DeedValue or DomainExit.
# ==============================================================================
class DeedResult:
    __slots__ = ("truth", "value", "confidence", "repair_chain", "notes")

    def __init__(
        self,
        truth: TruthValue,
        value: Union[DeedValue, _DomainExitSentinel] = DomainExit,
        confidence: Optional[DeedValue] = None,
        repair_chain: Optional[List[str]] = None,
        notes: str = "",
    ) -> None:
        if not isinstance(truth, TruthValue):
            raise DomainExitError("DeedResult.truth must be a TruthValue")
        if not (isinstance(value, DeedValue) or value is DomainExit):
            raise DomainExitError("DeedResult.value must be DeedValue or DomainExit")
        self.truth: TruthValue = truth
        self.value: Union[DeedValue, _DomainExitSentinel] = value
        # confidence defaults to the floor (sigma-k minimum), never 0.
        self.confidence: DeedValue = confidence if confidence is not None else DeedValue(EPSILON)
        self.repair_chain: List[str] = repair_chain if repair_chain is not None else []
        self.notes: str = notes

    @property
    def has_value(self) -> bool:
        return isinstance(self.value, DeedValue)

    @property
    def exited(self) -> bool:
        return self.value is DomainExit

    def match(
        self,
        on_true: Callable[["DeedResult"], Any],
        on_false: Callable[["DeedResult"], Any],
        on_unknown: Callable[["DeedResult"], Any],
        on_probe: Callable[["DeedResult"], Any],
    ) -> Any:
        """Force the caller to handle all four truth states. No default branch."""
        return {
            TruthValue.TRUE: on_true,
            TruthValue.FALSE: on_false,
            TruthValue.UNKNOWN: on_unknown,
            TruthValue.PROBE: on_probe,
        }[self.truth](self)

    def __repr__(self) -> str:
        v = repr(self.value)
        return (
            f"DeedResult(truth={self.truth.value}, value={v}, "
            f"confidence={self.confidence.value:g}, notes={self.notes!r})"
        )


# ==============================================================================
# MAYBE[T]  (typed absence wrapper)
# ------------------------------------------------------------------------------
# For optional fields that are not numeric DeedValues. Forces the caller to
# handle the absence case explicitly; there is no silent None.
# ==============================================================================
T = TypeVar("T")


class Maybe(Generic[T]):
    __slots__ = ("_present", "_value")

    def __init__(self, value: Union[T, _DomainExitSentinel] = DomainExit) -> None:
        if value is DomainExit:
            self._present = False
            self._value = DomainExit
        else:
            if value is None:
                raise DomainExitError("Maybe(None) is forbidden; use Maybe() for absence")
            self._present = True
            self._value = value

    @classmethod
    def absent(cls) -> "Maybe[T]":
        return cls()

    @property
    def present(self) -> bool:
        return self._present

    def unwrap(self) -> T:
        if not self._present:
            raise DomainExitError("unwrap on absent Maybe (the question dissolved)")
        return self._value  # type: ignore[return-value]

    def unwrap_or(self, default: T) -> T:
        return self._value if self._present else default  # type: ignore[return-value]

    def __repr__(self) -> str:
        return f"Maybe({self._value!r})" if self._present else "Maybe(absent)"


def require_value(result: DeedResult) -> DeedValue:
    """Extract a DeedValue from a DeedResult or raise DomainExit. Use only when
    the caller has already established the result must carry a value."""
    if not result.has_value:
        raise DomainExitError(f"required value absent: {result.notes}")
    return result.value  # type: ignore[return-value]
