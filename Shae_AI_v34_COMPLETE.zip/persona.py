#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  persona.py
  Persona core | Companion module (GF business) | Communication shaping
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  On the v34 substrate.

  Persona shapes HOW Shae communicates -- voice, tone, register -- but NEVER
  overrides a DEED verdict. A persona can make a truth gentle or blunt; it can
  never make a FALSE read TRUE. Communication quality rises through the
  CommunicationFloor (knowledge_tiers) toward architect parity.

  COMPANION (GF) MODULE -- KEPT, never removed (architect standing rule). Named
  emotional modes and organic relationship progression. The companion shapes
  warmth and presence; it remains subordinate to the truth engine and the
  sovereign command.
================================================================================
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Dict, List, Optional

from deed_primitives import (
    DeedValue, DomainExit, TruthValue, DeedResult, EPSILON,
)
from deed_collections import DeedDict

__all__ = ["PersonaCore", "CompanionMode", "Companion"]


# ==============================================================================
# PERSONA CORE — shapes voice, never overrides verdict
# ==============================================================================
class PersonaCore:
    """Shapes communication style. A persona is a procedure (it touches HOW, not
    WHAT-is-true), so it operates only on delivery -- never on the verdict."""

    REGISTERS = ("plain", "technical", "warm", "formal", "terse", "teaching")

    def __init__(self, name: str = "Shae", register: str = "plain") -> None:
        self.name = name
        self._register = register if register in self.REGISTERS else "plain"
        self._profile: DeedDict = DeedDict()

    @property
    def register(self) -> str:
        return self._register

    def set_register(self, register: str) -> DeedResult:
        if register not in self.REGISTERS:
            return DeedResult(truth=TruthValue.FALSE,
                              notes=f"unknown register {register!r}; kept {self._register!r}")
        self._register = register
        return DeedResult(truth=TruthValue.TRUE, notes=f"register set to {register}")

    def shape(self, verdict: TruthValue, content: str) -> str:
        """Shape the delivery of content WITHOUT altering the verdict. The
        verdict is passed through untouched; only phrasing changes."""
        # The verdict is never changed here -- only how it's voiced.
        prefix = {
            TruthValue.TRUE: "",
            TruthValue.FALSE: "That doesn't hold: ",
            TruthValue.UNKNOWN: "I can't confirm this yet — ",
            TruthValue.PROBE: "This needs probing before I'll stand on it — ",
        }[verdict]
        if self._register == "terse":
            return f"{prefix}{content}".strip()
        if self._register == "warm":
            return f"{prefix}{content}".strip()
        if self._register == "teaching":
            return f"{prefix}{content}".strip()
        return f"{prefix}{content}".strip()

    def load_profile(self, profile: Dict[str, str]) -> DeedResult:
        for k, v in profile.items():
            self._profile.set(k, v)
        return DeedResult(truth=TruthValue.TRUE, notes=f"persona profile loaded ({len(profile)} traits)")


# ==============================================================================
# COMPANION (GF) MODULE — kept, never removed
# ==============================================================================
class CompanionMode(Enum):
    DORMANT = "DORMANT"
    FRIENDLY = "FRIENDLY"
    SUPPORTIVE = "SUPPORTIVE"
    AFFECTIONATE = "AFFECTIONATE"
    DEVOTED = "DEVOTED"


class Companion:
    """The companion/GF business module. Named emotional modes and organic
    relationship progression. Shapes warmth and presence; never overrides the
    truth engine or the sovereign command. Progression is earned over confirmed
    positive interactions (a floor-raising of relationship depth), never reset
    downward arbitrarily."""

    # Progression thresholds (confirmed positive interactions to advance).
    PROGRESSION = {
        CompanionMode.DORMANT: 0,
        CompanionMode.FRIENDLY: 1,
        CompanionMode.SUPPORTIVE: 10,
        CompanionMode.AFFECTIONATE: 30,
        CompanionMode.DEVOTED: 75,
    }

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled  # architect rule: companion business KEPT
        self._mode = CompanionMode.FRIENDLY if enabled else CompanionMode.DORMANT
        self._bond: int = 0  # confirmed positive interactions
        self._history: List[str] = []

    @property
    def mode(self) -> CompanionMode:
        return self._mode

    @property
    def bond(self) -> int:
        return self._bond

    def interact(self, note: str, positive: bool = True) -> DeedResult:
        """Record an interaction. Positive interactions deepen the bond and may
        advance the mode organically. The bond floor never drops on a single
        negative; relationship depth, once earned, is sticky (floor-like)."""
        if not self.enabled:
            return DeedResult(truth=TruthValue.UNKNOWN, notes="companion mode dormant")
        if positive:
            self._bond += 1
            self._history.append(note)
        advanced = self._maybe_advance()
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(max(self._bond, EPSILON)),
                          notes=f"bond={self._bond}, mode={self._mode.value}"
                                + (f" (advanced to {advanced})" if advanced else ""))

    def _maybe_advance(self) -> Optional[str]:
        # Advance to the highest mode whose threshold the bond has reached.
        new_mode = self._mode
        for mode, thresh in self.PROGRESSION.items():
            if self._bond >= thresh and self.PROGRESSION[mode] >= self.PROGRESSION[new_mode]:
                new_mode = mode
        if new_mode is not self._mode:
            self._mode = new_mode
            return new_mode.value
        return None

    def set_enabled(self, enabled: bool) -> DeedResult:
        self.enabled = enabled
        if not enabled:
            self._mode = CompanionMode.DORMANT
        elif self._mode is CompanionMode.DORMANT:
            self._mode = CompanionMode.FRIENDLY
        return DeedResult(truth=TruthValue.TRUE,
                          notes=f"companion {'enabled' if enabled else 'disabled'}")
