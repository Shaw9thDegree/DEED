#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  knowledge_tiers.py
  THREE-TIER KNOWLEDGE ARCHITECTURE
--------------------------------------------------------------------------------
  Architect: Jarad Shaw. On the immutable-floor substrate + deed_kernel.

  THE TIERING (architect-specified this session)
  ----------------------------------------------
  TIER 1 — COMMON BASE  (always active)
    Language, communication, common sense, operation of platforms/systems/tools.
    Level: a 4th-year college graduate's general + common knowledge. This is the
    runtime brain Shae thinks with by default. Always live, low weight, fast.

  TIER 2 — PROFESSIONAL / DEEP  (dormant until needed)
    Domain-expert depth (the "second file"). Stays asleep to keep active context
    light = optimum efficiency. The instant a TASK BEGINS that needs a domain,
    that domain's deep knowledge PIPE-LINKS in; when the task ends it goes
    dormant again. Shae may UPGRADE this tier as she learns (gated like a
    constant: confirmed, non-contradicting, sovereign-aware).

  TIER 3 — SOVEREIGN / DEED-CORE  (the reference frame; always present)
    The constants, the Laws, the first-principles trail, the sovereign command.
    Not "looked up" — it is the ground every verdict is measured against. Deepest
    tier. Present always, but distinct from common and professional: it does not
    answer questions, it GROUNDS them.

  Communication target: Shae must communicate as well as the architect; until she
  does, she RAISES her own communication floor through confirmed experience
  (the personal-floor mechanic). Tracked here as a rising floor, never reset down.
================================================================================
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Dict, List, Optional

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult, EPSILON,
)
from deed_collections import DeedDict
from deed_kernel import DeedKernel, ProofObligation

__all__ = [
    "Tier", "KnowledgeEntry", "CommonBase", "ProfessionalKnowledge",
    "SovereignCore", "KnowledgePipe", "CommunicationFloor",
]


class Tier(Enum):
    COMMON = "COMMON"             # always active, 4yr-grad general
    PROFESSIONAL = "PROFESSIONAL"  # dormant, pipe-linked on task
    SOVEREIGN = "SOVEREIGN"       # reference frame, always present


# ==============================================================================
# KNOWLEDGE ENTRY
# ==============================================================================
class KnowledgeEntry:
    __slots__ = ("key", "content", "tier", "domain_id", "confidence", "added_at", "confirmed")

    def __init__(self, key: str, content: str, tier: Tier,
                 domain_id: Optional[int] = None,
                 confidence: Optional[DeedValue] = None,
                 confirmed: bool = False) -> None:
        if not key or not key.strip():
            raise DomainExitError("knowledge entry needs a key")
        if content is None or not str(content).strip():
            raise DomainExitError("knowledge entry needs content (absence is not knowledge)")
        self.key = key.strip()
        self.content = content
        self.tier = tier
        self.domain_id = domain_id
        # Confidence is a floored DeedValue (never 0) — knowledge that exists has
        # at least floor presence.
        self.confidence = confidence if confidence is not None else DeedValue(EPSILON)
        self.added_at = time.time()
        self.confirmed = confirmed

    def __repr__(self) -> str:
        return f"KnowledgeEntry({self.key!r}, tier={self.tier.value}, confirmed={self.confirmed})"


# ==============================================================================
# TIER 1 — COMMON BASE  (always active)
# ==============================================================================
class CommonBase:
    """The 4th-year-graduate general + common knowledge Shae runs on by default.
    Language, communication, common sense, platform/tool operation. Always live."""

    __slots__ = ("_entries", "_categories")

    # The standing competencies the common base guarantees at all times.
    BASELINE_COMPETENCIES = (
        "language_and_grammar",
        "communication_and_register",
        "common_sense_reasoning",
        "platform_operation",        # how to operate OSes, apps, interfaces
        "system_operation",          # how to operate Shae's own systems/commands
        "tool_use_basics",
        "general_academic_4yr",      # 4th-year-college-graduate breadth
        "everyday_world_knowledge",
    )

    def __init__(self) -> None:
        self._entries: DeedDict = DeedDict()
        self._categories = set(self.BASELINE_COMPETENCIES)
        for comp in self.BASELINE_COMPETENCIES:
            self._entries.set(comp, KnowledgeEntry(
                comp, f"baseline competency: {comp}", Tier.COMMON, confirmed=True,
                confidence=DeedValue(72)))  # 4yr-grad standing, not claimed-perfect

    def has_competency(self, name: str) -> bool:
        return name in self._categories

    def get(self, key: str) -> object:
        return self._entries.get(key)

    def add(self, entry: KnowledgeEntry) -> DeedResult:
        if entry.tier is not Tier.COMMON:
            return DeedResult(truth=TruthValue.FALSE,
                              notes="only COMMON-tier entries belong in CommonBase")
        self._entries.set(entry.key, entry)
        self._categories.add(entry.key)
        return DeedResult(truth=TruthValue.TRUE, notes=f"common knowledge {entry.key} active")

    def count(self) -> DeedValue:
        return self._entries.count()


# ==============================================================================
# TIER 2 — PROFESSIONAL / DEEP  (dormant; pipe-links on task; upgradable)
# ==============================================================================
class ProfessionalKnowledge:
    """Domain-expert depth that stays DORMANT to keep active context light. A
    domain is woken only when a task needs it (via KnowledgePipe), then sleeps
    again. Upgradable as Shae learns, gated like a constant."""

    __slots__ = ("_by_domain", "_active_domains", "_kernel")

    def __init__(self, kernel: Optional[DeedKernel] = None) -> None:
        # domain_id -> list[KnowledgeEntry]; all dormant until activated.
        self._by_domain: Dict[int, List[KnowledgeEntry]] = {}
        self._active_domains: set = set()
        self._kernel = kernel  # for gating upgrades like constants

    def register(self, entry: KnowledgeEntry) -> DeedResult:
        if entry.tier is not Tier.PROFESSIONAL or entry.domain_id is None:
            return DeedResult(truth=TruthValue.FALSE,
                              notes="professional entry needs PROFESSIONAL tier + domain_id")
        self._by_domain.setdefault(entry.domain_id, []).append(entry)
        return DeedResult(truth=TruthValue.TRUE,
                          notes=f"deep knowledge registered (dormant) for domain {entry.domain_id}")

    def is_dormant(self, domain_id: int) -> bool:
        return domain_id not in self._active_domains

    def wake(self, domain_id: int) -> DeedResult:
        """Pipe-link a domain's deep knowledge into active context."""
        if domain_id not in self._by_domain:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes=f"no deep knowledge yet for domain {domain_id}")
        self._active_domains.add(domain_id)
        n = len(self._by_domain[domain_id])
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(n),
                          notes=f"domain {domain_id} deep knowledge linked ({n} entries)")

    def sleep(self, domain_id: int) -> DeedResult:
        """Return a domain to dormancy when the task ends (optimum efficiency)."""
        self._active_domains.discard(domain_id)
        return DeedResult(truth=TruthValue.TRUE, notes=f"domain {domain_id} dormant")

    def active(self, domain_id: int) -> List[KnowledgeEntry]:
        if domain_id not in self._active_domains:
            return []  # dormant: not in active context
        return list(self._by_domain.get(domain_id, []))

    def upgrade(self, entry: KnowledgeEntry, proof_trail: List[str]) -> DeedResult:
        """Shae upgrades her professional knowledge as she learns. Gated like a
        constant: must be grounded (proof trail) and must not contradict existing
        confirmed deep knowledge in the same domain."""
        if entry.tier is not Tier.PROFESSIONAL or entry.domain_id is None:
            return DeedResult(truth=TruthValue.FALSE,
                              notes="upgrade must be PROFESSIONAL tier with domain_id")
        if len(proof_trail) == 0:
            return DeedResult(truth=TruthValue.FALSE,
                              notes="upgrade rejected: no trail grounding the new knowledge")
        # Non-contradiction with confirmed entries in the same domain.
        for existing in self._by_domain.get(entry.domain_id, []):
            if existing.confirmed and _contradicts(entry.content, existing.content):
                return DeedResult(truth=TruthValue.FALSE,
                                  notes="upgrade rejected: contradicts confirmed deep knowledge")
        entry.confirmed = True
        self._by_domain.setdefault(entry.domain_id, []).append(entry)
        return DeedResult(truth=TruthValue.TRUE,
                          notes=f"professional knowledge upgraded in domain {entry.domain_id}")


def _contradicts(a: str, b: str) -> bool:
    """Conservative textual contradiction check for deep-knowledge upgrades."""
    an = a.lower().strip().rstrip(".")
    bn = b.lower().strip().rstrip(".")
    return an == "not " + bn or bn == "not " + an


# ==============================================================================
# TIER 3 — SOVEREIGN / DEED-CORE  (reference frame; always present)
# ==============================================================================
class SovereignCore:
    """The deepest tier: the constants, the Laws, the first-principles trail, the
    sovereign command. It does not answer questions — it GROUNDS them. Always
    present as the frame every verdict is measured against. Read-through to the
    kernel's constant store; never a lookup table that can be edited like data."""

    __slots__ = ("_kernel", "_architect")

    def __init__(self, kernel: DeedKernel, architect: str = "Jarad Shaw") -> None:
        self._kernel = kernel
        self._architect = architect  # sovereignty stays under the architect

    @property
    def architect(self) -> str:
        return self._architect

    def ground_of(self, claim_trail: List[str]) -> DeedResult:
        """A claim is grounded iff its trail reaches the constants (the frame).
        This is the reference-frame check, not an answer to the claim."""
        if len(claim_trail) == 0:
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes="ungrounded: no trail to the sovereign/DEED-core frame")
        const_ids = {c.id for c in self._kernel.constants.all()}
        const_statements = self._kernel.constants.statements()
        # Grounded if any trail link references a known constant id or statement,
        # or the first enacted action E(E)=E (the root).
        for link in claim_trail:
            if link in const_ids or link in const_statements or link.upper() in ("E(E)=E", "C=N!=0"):
                return DeedResult(truth=TruthValue.TRUE,
                                  notes="grounded to the DEED-core reference frame")
        return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                          notes="trail does not yet reach the core frame")


# ==============================================================================
# KNOWLEDGE PIPE  — wakes the right professional domain when a task begins
# ==============================================================================
class KnowledgePipe:
    """Links deep knowledge in the moment a task begins and releases it when the
    task ends. Common base handles everything up to the point a task needs depth;
    then the pipe wakes exactly the domain required, no more (optimum efficiency)."""

    __slots__ = ("common", "professional", "sovereign", "_open_tasks")

    def __init__(self, common: CommonBase, professional: ProfessionalKnowledge,
                 sovereign: SovereignCore) -> None:
        self.common = common
        self.professional = professional
        self.sovereign = sovereign
        self._open_tasks: Dict[str, int] = {}  # task_id -> domain_id woken

    def begin_task(self, task_id: str, domain_id: int) -> DeedResult:
        """Task starts -> pipe-link the domain's deep knowledge. Until this, the
        common base alone is in play."""
        woke = self.professional.wake(domain_id)
        if woke.truth is TruthValue.TRUE:
            self._open_tasks[task_id] = domain_id
        return woke

    def end_task(self, task_id: str) -> DeedResult:
        """Task ends -> deep knowledge returns to dormancy."""
        domain_id = self._open_tasks.pop(task_id, None)
        if domain_id is None:
            return DeedResult(truth=TruthValue.UNKNOWN, notes="no open task by that id")
        return self.professional.sleep(domain_id)

    def active_context(self, task_id: Optional[str] = None) -> Dict[str, object]:
        """What is in active context right now: always the common base; plus the
        woken professional domain only if a task is open."""
        ctx: Dict[str, object] = {"common_base": "active (4yr-grad general)"}
        if task_id is not None and task_id in self._open_tasks:
            d = self._open_tasks[task_id]
            ctx["professional_domain"] = d
            ctx["deep_entries"] = len(self.professional.active(d))
        else:
            ctx["professional"] = "dormant"
        ctx["sovereign_core"] = "present (reference frame)"
        return ctx


# ==============================================================================
# COMMUNICATION FLOOR  — rises through confirmed experience toward the architect
# ==============================================================================
class CommunicationFloor:
    """Shae must communicate as well as the architect; until she does she raises
    her communication floor through confirmed experience. The floor only rises
    (personal-floor mechanic): confirmed communicative competence becomes the new
    minimum she never falls below. Target is parity with the architect."""

    __slots__ = ("_floor", "_target", "_confirmations")

    def __init__(self) -> None:
        # Start at the common-base communicative level (4yr-grad), floored.
        self._floor: DeedValue = DeedValue(72)
        self._target: str = "architect-parity"
        self._confirmations: List[str] = []

    @property
    def level(self) -> DeedValue:
        return self._floor

    @property
    def at_parity(self) -> bool:
        # Parity is reached when confirmed communicative reach meets the target
        # band; represented as floor >= 100 (the architect-parity mark).
        return self._floor.value >= 100.0

    def confirm_experience(self, note: str, gain: float) -> DeedResult:
        """A confirmed communicative success raises the floor. Never lowers it.
        Gain must be positive and bounded; the floor is monotonic upward."""
        if gain <= 0:
            return DeedResult(truth=TruthValue.FALSE,
                              notes="communication floor only rises on confirmed gain")
        raised = self._floor.value + gain
        self._floor = DeedValue(raised)
        self._confirmations.append(note)
        return DeedResult(truth=TruthValue.TRUE, value=self._floor,
                          notes=f"communication floor raised to {raised:g}"
                                + (" — architect parity reached" if raised >= 100 else ""))
