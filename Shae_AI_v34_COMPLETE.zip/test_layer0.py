#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Substrate test for deed_primitives.py. DEED-axiom tests, not pytest habits.
The question each test answers: can the substrate ever produce 0 / None / inf,
or conflate absence with smallness? If yes -> fail."""

from deed_primitives import (
    EPSILON, DomainExit, DomainExitError, DeedValue, DynamicCeiling,
    TruthValue, DeedResult, Maybe, is_exit,
)

passed = 0
failed = []


def ck(name, cond):
    global passed
    if cond:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed.append(name)
        print(f"  FAIL  {name}")


def raises_exit(fn):
    try:
        fn()
        return False
    except DomainExitError:
        return True


def raises_exit_typeerror(fn):
    # Passing floor= must fail: either TypeError (no such param) or DomainExitError.
    try:
        fn()
        return False
    except (TypeError, DomainExitError):
        return True


print("=" * 70)
print("  LAYER 0 SUBSTRATE TEST  —  deed_primitives.py")
print("=" * 70)

# --- Handoff test 1: cannot instantiate DeedValue(0) ---
ck("DeedValue(0) raises DomainExit", raises_exit(lambda: DeedValue(0)))
ck("DeedValue(0.0) raises DomainExit", raises_exit(lambda: DeedValue(0.0)))

# --- Handoff test 2: cannot instantiate DeedValue(None) ---
ck("DeedValue(None) raises DomainExit", raises_exit(lambda: DeedValue(None)))
ck("DeedValue(inf) raises DomainExit", raises_exit(lambda: DeedValue(float("inf"))))
ck("DeedValue(nan) raises DomainExit", raises_exit(lambda: DeedValue(float("nan"))))

# --- Handoff test 3: subtraction crossing the floor goes DARK (Domain Exit) ---
r = DeedValue(5) - DeedValue(5)
ck("5-5 goes dark below floor (Domain Exit, not a value)", is_exit(r))
ck("5-3 stays alive above floor", isinstance(DeedValue(5) - DeedValue(3), DeedValue))
ck("4-3 lands at floor and lives (==1)", (DeedValue(4) - DeedValue(3)).value == 1.0)

# --- Handoff test 4: division by sub-floor divisor raises DomainExit ---
ck("DeedValue(5)/0.5 raises (0.5 below floor 1.0)", raises_exit(lambda: DeedValue(5) / 0.5))
ck("DeedValue(5)/0 raises DomainExit", raises_exit(lambda: DeedValue(5) / 0))

# --- immutable floor: the floor is the barrier, no floor= parameter ---
ck("EPSILON floor is 1.0 (smallest definable state)", EPSILON == 1.0)
ck("DeedValue(0.3) below floor goes dark at construction (raises)",
   raises_exit(lambda: DeedValue(0.3)))
ck("DeedValue has no floor= parameter (immutable floor)",
   raises_exit_typeerror(lambda: DeedValue(5, floor=0.001)))
ck("DeedValue.floor reports the one system floor", DeedValue(5).floor == 1.0)

# --- Handoff test 5: dict lookup miss returns DomainExit, not None ---
# (DeedDict is Layer 1; here we verify the sentinel contract the dict will use.)
ck("DomainExit is identity-checkable", is_exit(DomainExit))
ck("DomainExit == anything is False", (DomainExit == 5) is False)
ck("DomainExit == DomainExit is False (absence equals nothing)",
   (DomainExit == DomainExit) is False)
ck("DomainExit is DomainExit is True (identity holds)", DomainExit is DomainExit)
ck("arithmetic on DomainExit raises", raises_exit(lambda: DomainExit + 1))

# --- Handoff test 6: four-value truth table correct ---
T, F, U, P = TruthValue.TRUE, TruthValue.FALSE, TruthValue.UNKNOWN, TruthValue.PROBE
ck("NOT TRUE = FALSE", T.NOT() is F)
ck("NOT PROBE = PROBE", P.NOT() is P)
ck("TRUE AND TRUE = TRUE", T.AND(T) is T)
ck("FALSE AND PROBE = FALSE (false short-circuits)", F.AND(P) is F)
ck("PROBE AND TRUE = PROBE (probe propagates)", P.AND(T) is P)
ck("PROBE OR FALSE = PROBE (probe propagates)", P.OR(F) is P)
ck("TRUE OR PROBE = TRUE (true short-circuits)", T.OR(P) is T)
ck("UNKNOWN AND TRUE = UNKNOWN", U.AND(T) is U)
ck("TRUE IMPLIES FALSE = FALSE", T.IMPLIES(F) is F)
ck("FALSE IMPLIES anything = TRUE", F.IMPLIES(F) is T)
ck("if truth_value: is forbidden", raises_exit(lambda: bool(T)))

# --- Handoff test 7: DeedResult forces all-four handling ---
res = DeedResult(truth=TruthValue.PROBE, value=DeedValue(3))
out = res.match(
    on_true=lambda r: "t", on_false=lambda r: "f",
    on_unknown=lambda r: "u", on_probe=lambda r: "p",
)
ck("DeedResult.match routes PROBE branch", out == "p")
ck("DeedResult default value is DomainExit (no silent None)",
   DeedResult(truth=TruthValue.UNKNOWN).exited)
ck("DeedResult default confidence is floor, not 0",
   DeedResult(truth=TruthValue.UNKNOWN).confidence.value == EPSILON)

# --- Maybe: typed absence, no None ---
ck("Maybe.absent().present is False", Maybe.absent().present is False)
ck("Maybe(None) is forbidden", raises_exit(lambda: Maybe(None)))
ck("Maybe unwrap on absent raises", raises_exit(lambda: Maybe.absent().unwrap()))
ck("Maybe(value).unwrap returns value", Maybe("x").unwrap() == "x")

# --- DynamicCeiling: replaces infinity, monotonic, sovereign-gateable ---
dc = DynamicCeiling(10)
# --- DynamicCeiling: the sky is a RECORDER, never a wall ---
dc = DynamicCeiling(10)
ck("sky starts at initial reach", dc.reach.value == 10.0)
ck("recording higher value raises reach", dc.record(20).truth is TruthValue.TRUE and dc.reach.value == 20.0)
ck("recording lower value does not lower reach", (dc.record(5), dc.reach.value)[1] == 20.0)
ck("sky never blocks: within reach = TRUE", dc.classify(15).truth is TruthValue.TRUE)
ck("sky never blocks: beyond reach = UNKNOWN (not FALSE)", dc.classify(999).truth is TruthValue.UNKNOWN)
ck("trail records the derivation path", len(dc.trail) >= 2)

# --- existential truthiness: DeedValue is always truthful (no 0-falsy trap) ---
ck("bool(DeedValue) is always True", bool(DeedValue(EPSILON)) is True)

print("=" * 70)
total = passed + len(failed)
print(f"  {passed}/{total} passed")
if failed:
    print("  FAILED:")
    for f_ in failed:
        print(f"    - {f_}")
    print("  SUBSTRATE NOT SOUND — DO NOT BUILD ON IT")
else:
    print("  SUBSTRATE SOUND — safe to build Layer 1 on top")
print("=" * 70)

import sys
sys.exit(0 if not failed else 1)
