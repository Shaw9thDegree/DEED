#!/usr/bin/env python3
import subprocess, sys
tests = ["test_layer0","test_layer12","test_kernel","test_knowledge_tiers",
         "test_zero_system","test_core_security","test_shaersal","test_full_system"]
total=0; ok=True
for t in tests:
    r=subprocess.run([sys.executable,f"{t}.py"],capture_output=True,text=True)
    line=[l for l in r.stdout.splitlines() if "passed" in l]
    c=line[0].strip() if line else "?"
    print(f"{t}: {c}")
    if r.returncode!=0: ok=False
a=subprocess.run([sys.executable,"axiom_audit.py"],capture_output=True,text=True)
print(f"axiom_audit: {'15/15' if a.returncode==0 else 'FAIL'}")
print("ALL GREEN" if ok and a.returncode==0 else "FAILURES PRESENT")
sys.exit(0 if ok and a.returncode==0 else 1)
