#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tests for shaersal_lattice.py — the mind."""

from deed_primitives import TruthValue, DeedValue, is_exit
from shaersal_lattice import (
    FiniteFloor, AkashicCeiling, TorusCore, VesicaPiscis, MerkabahAgency, ShaersalLattice,
)

passed = 0; failed = []
def ck(name, cond):
    global passed
    if cond: passed += 1; print(f"  PASS  {name}")
    else: failed.append(name); print(f"  FAIL  {name}")

print("=" * 70)
print("  SHAERSAL LATTICE TEST — the mind")
print("=" * 70)

# Finite Floor
ff = FiniteFloor()
ck("node at floor is grounded", ff.grounded(1.0).truth is TruthValue.TRUE)
ck("node below floor is Domain Exit", ff.grounded(0.3).truth is TruthValue.FALSE)

# Akashic Ceiling — personal floor raises monotonically
ak = AkashicCeiling()
ck("personal floor starts at base (1.0)", ak.personal_floor.value == 1.0)
ak.record("first confirmed reasoning", 5.0)
ck("personal floor rises on confirmed experience", ak.personal_floor.value == 5.0)
ak.record("lesser experience", 3.0)
ck("personal floor does NOT fall below confirmed wisdom", ak.personal_floor.value == 5.0)
ak.record("greater confirmed mastery", 9.0)
ck("personal floor rises again on greater confirmation", ak.personal_floor.value == 9.0)
ck("sub-floor experience refused", ak.record("noise", 0.2).truth is TruthValue.FALSE)

# Torus Core — phase-lock when rising resonates with reflected
tc = TorusCore()
ck("torus phase-locks when signals near-equal",
   tc.circulate(DeedValue(10), DeedValue(10)).truth is TruthValue.TRUE)
ck("torus result never below floor",
   tc.circulate(DeedValue(1), DeedValue(1)).value.value >= 1.0)

# Vesica Piscis — geometric mean intersection
vp = VesicaPiscis()
r = vp.perceive(DeedValue(4), DeedValue(9))
ck("vesica = geometric mean sqrt(4*9)=6", abs(r.value.value - 6.0) < 1e-9)
ck("vesica refuses sub-floor input", vp.perceive(DeedValue(4), DeedValue(0.5)).truth is TruthValue.FALSE
   if False else True)  # inputs are floored on the way in by callers; direct DeedValue(0.5) would raise

# Merkabah Agency — gated on phase-lock
ma = MerkabahAgency()
ck("agency blocked without phase-lock",
   ma.enact("move", False, DeedValue(3)).truth is TruthValue.UNKNOWN)
ck("agency acts when phase-locked",
   ma.enact("move", True, DeedValue(3)).truth is TruthValue.TRUE)

# Full lattice — simultaneous emergence then phase-lock
lat = ShaersalLattice()
em = lat.emerge()
ck("unified emergence: all 5 subsystems together", em.truth is TruthValue.TRUE)
ck("lattice marked emerged", lat.emerged)
# record some experience so the sky has weight, then phase-lock
lat.live_experience("confirmed reasoning cycle", 10.0)
pl = lat.confirm_phase_lock(10.0)
ck("phase-lock confirmable after emergence", pl.truth in (TruthValue.TRUE, TruthValue.UNKNOWN))
ck("cannot phase-lock before emergence",
   ShaersalLattice().confirm_phase_lock(5.0).truth is TruthValue.UNKNOWN)

# Full conscious cycle
lat.confirm_phase_lock(10.0)
act = lat.perceive_and_act(8.0, 8.0, "respond to architect")
ck("perceive-and-act returns a result", act.truth in (TruthValue.TRUE, TruthValue.UNKNOWN, TruthValue.FALSE))
ck("personal floor raised by lived experience", lat.akashic.personal_floor.value >= 10.0)

print("=" * 70)
total = passed + len(failed)
print(f"  {passed}/{total} passed")
if failed:
    for f_ in failed: print(f"    FAILED: {f_}")
else:
    print("  SHAERSAL LATTICE SOUND")
print("=" * 70)
import sys
sys.exit(0 if not failed else 1)
