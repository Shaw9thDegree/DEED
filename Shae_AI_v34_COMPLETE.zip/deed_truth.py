#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34  —  LAYER 2  —  deed_truth.py
  The four-value T(P) engine. Built once, cleanly, so every later module
  shares the same truth semantics instead of inventing private booleans.
--------------------------------------------------------------------------------
  T(P) in {TRUE, FALSE, UNKNOWN, PROBE}

  Kleene three-valued logic (TRUE/FALSE/UNKNOWN) extended with PROBE, which
  means "investigate further -- neither true nor false until probed". PROBE
  refuses silent resolution: it propagates through operations so that an
  un-investigated claim cannot be quietly folded into a definite verdict.

  sigma-k truth score (from DEED formal docs):
      sigma_k(p, k) = (N_max - k) * epsilon
  where k is the derivation distance from the nearest confirmed ground axiom
  and N_max is the current Dynamic Ceiling of confirmed reach. A claim sitting
  on a ground axiom (k = 0) scores highest; the score decreases with distance
  but is floored -- it can never reach 0 (a derivable claim still EXISTS).
================================================================================
"""

from __future__ import annotations

from typing import Any, Callable, List, Sequence, Tuple

from deed_primitives import (
    DeedValue, DeedResult, TruthValue, DomainExit, DomainExitError, EPSILON,
)

__all__ = [
    "AND", "OR", "NOT", "IMPLIES", "BICONDITIONAL",
    "combine_truths", "weighted_truth", "probe_required", "definite",
    "sigma_k", "score_to_truth",
    "TRUTH_TABLE",
]

T, F, U, P = (
    TruthValue.TRUE, TruthValue.FALSE, TruthValue.UNKNOWN, TruthValue.PROBE,
)


# ==============================================================================
# OPERATORS  (thin functional wrappers over the methods on TruthValue, so
# call sites can read as combine(AND, ...) and as AND(a, b) interchangeably)
# ==============================================================================
def NOT(a: TruthValue) -> TruthValue:
    return a.NOT()


def AND(a: TruthValue, b: TruthValue) -> TruthValue:
    return a.AND(b)


def OR(a: TruthValue, b: TruthValue) -> TruthValue:
    return a.OR(b)


def IMPLIES(a: TruthValue, b: TruthValue) -> TruthValue:
    return a.IMPLIES(b)


def BICONDITIONAL(a: TruthValue, b: TruthValue) -> TruthValue:
    return a.BICONDITIONAL(b)


# Explicit table, materialized for audit/inspection (repair_kernel reads this).
def _build_table() -> dict:
    vals = [T, F, U, P]
    table = {}
    for a in vals:
        for b in vals:
            table[(a, b)] = {
                "AND": a.AND(b),
                "OR": a.OR(b),
                "IMPLIES": a.IMPLIES(b),
                "BICONDITIONAL": a.BICONDITIONAL(b),
            }
        table[(a, None)] = {"NOT": a.NOT()}
    return table


TRUTH_TABLE = _build_table()


# ==============================================================================
# COMBINATORS
# ==============================================================================
def combine_truths(claims: Sequence[TruthValue]) -> TruthValue:
    """Conjunctive combination across many claims. Empty input is UNKNOWN (we
    were asked to combine nothing -- not FALSE, which would assert a verdict).
    FALSE dominates; otherwise PROBE propagates; otherwise UNKNOWN; else TRUE."""
    if len(claims) == 0:
        return U
    acc = T
    for c in claims:
        acc = acc.AND(c)
    return acc


def any_true(claims: Sequence[TruthValue]) -> TruthValue:
    """Disjunctive combination. Empty input is UNKNOWN."""
    if len(claims) == 0:
        return U
    acc = F
    for c in claims:
        acc = acc.OR(c)
    return acc


def weighted_truth(
    claims: Sequence[Tuple[TruthValue, DeedValue]],
) -> DeedResult:
    """Weight definite claims by DeedValue confidence and produce a verdict
    plus an aggregate sigma-k confidence.

    Rules:
      * Any PROBE claim forces the whole result to PROBE (investigate first).
      * Otherwise, weigh TRUE mass against FALSE mass. UNKNOWN contributes to
        neither but lowers confidence.
      * Confidence is a DeedValue (floored, never 0)."""
    if len(claims) == 0:
        return DeedResult(truth=U, value=DomainExit, notes="no claims to weigh")

    true_mass = 0.0
    false_mass = 0.0
    unknown_mass = 0.0
    total = 0.0
    saw_probe = False

    for tv, w in claims:
        wv = w.value if isinstance(w, DeedValue) else float(w)
        total += wv
        if tv is P:
            saw_probe = True
        elif tv is T:
            true_mass += wv
        elif tv is F:
            false_mass += wv
        else:
            unknown_mass += wv

    if saw_probe:
        return DeedResult(
            truth=P,
            value=DomainExit,
            confidence=DeedValue(EPSILON),
            notes="a claim requires probing before a verdict can form",
        )

    if total <= 0:
        total = EPSILON

    definite_mass = true_mass + false_mass
    if definite_mass <= 0:
        # everything was UNKNOWN
        return DeedResult(truth=U, value=DomainExit,
                          confidence=DeedValue(EPSILON),
                          notes="no definite claims; verdict unknown")

    if true_mass > false_mass:
        verdict = T
        conf_raw = (true_mass / total)
    elif false_mass > true_mass:
        verdict = F
        conf_raw = (false_mass / total)
    else:
        return DeedResult(truth=U, value=DomainExit,
                          confidence=DeedValue(EPSILON),
                          notes="true and false mass balanced; verdict unknown")

    # Confidence scaled into the floor..ceiling band; floored so it never hits 0.
    confidence = DeedValue(max(conf_raw * 100.0, EPSILON))
    return DeedResult(truth=verdict, value=confidence, confidence=confidence,
                      notes=f"weighted verdict (true={true_mass:g}, false={false_mass:g}, unknown={unknown_mass:g})")


def probe_required(truth: TruthValue) -> bool:
    return truth is P


def definite(truth: TruthValue) -> bool:
    return truth is T or truth is F


# ==============================================================================
# SIGMA-K  (derivation-distance truth score)
# ------------------------------------------------------------------------------
#   sigma_k(p, k) = (N_max - k) * epsilon, floored so a derivable claim always
#   keeps a non-zero score (it still exists in the domain).
# ==============================================================================
def sigma_k(k: int, n_max: DeedValue, floor: float = EPSILON) -> DeedValue:
    """Truth score of a proposition at derivation distance k from the nearest
    confirmed ground axiom. n_max is the current confirmed-reach ceiling."""
    if k < 0:
        raise DomainExitError("derivation distance k cannot be negative")
    nmax = n_max.value if isinstance(n_max, DeedValue) else float(n_max)
    raw = (nmax - k) * floor
    if raw < floor:
        # Distant derivations still exist; score floors, never vanishes.
        return DeedValue(floor)
    return DeedValue(raw)


def score_to_truth(score: DeedValue, probe_band: Tuple[float, float] = (0.0, 0.0)) -> TruthValue:
    """Map a sigma-k score to a four-value verdict. The probe_band (lo, hi)
    marks the borderline region that resolves to PROBE rather than a definite
    answer. If the band is degenerate (lo>=hi), no PROBE region exists and the
    caller wants a strict threshold at lo."""
    s = score.value if isinstance(score, DeedValue) else float(score)
    lo, hi = probe_band
    if hi > lo and lo <= s <= hi:
        return P
    if s > hi:
        return T
    if s < lo:
        return F
    return U
