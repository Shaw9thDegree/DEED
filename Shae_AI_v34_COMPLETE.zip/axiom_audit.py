#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  axiom_audit.py
  THE 560 PURGE PASS
--------------------------------------------------------------------------------
  Architect directive (this session):
    - Purge self-referential 'DEED is complete/consistent/honest/sovereign/
      open/eternal' entries from the 560. Those describe the SYSTEM, not
      existence. They are System Supreme rules (or Domain rules), not axioms.
    - Refile them as rules.
    - Renumber the TRUE mathematical constants into a clean sequence.
    - No constant that self-references the system survives as an axiom; all such
      are null as axioms and rewritten as system/domain rules governing scope.

  This module classifies each axiom statement by category using markers, splits
  the corpus into (constants, system_rules, domain_rules), renumbers constants,
  and loads them into a DeedKernel with the separation enforced.

  IMPORTANT: this is the CLASSIFIER + LOADER. The full 560 statement corpus is
  supplied by the caller (parsed from the DEED v1.1 PDF). Here we encode the
  classification logic and provide a self-test on a representative sample drawn
  verbatim-in-meaning from the 560 set, so the logic is verified before the full
  corpus is run through it.
================================================================================
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from deed_primitives import TruthValue, DeedResult
from deed_kernel import (
    DeedKernel, Constant, SystemRule, DomainRule, Category,
)

__all__ = ["classify_axiom", "audit_corpus", "load_audited_kernel", "AuditReport"]


# Markers that identify a statement as ABOUT THE SYSTEM ITSELF (a mechanic),
# therefore NOT a mathematical constant. These are the self-referential ones.
_SYSTEM_SELF_MARKERS = [
    "deed is complete", "deed is consistent", "deed is honest", "deed is sovereign",
    "deed is open", "deed is eternal", "deed v", "the deed v1.1 ledger",
    "the system is", "this system", "the ledger is", "the framework is",
    "any reasoning system implementing", "deed-based cognitive architecture",
    "the consciousness threshold of deed", "no axiom in deed references",
    "every axiom in deed is derivable",
    # ledger / eternity / finality self-references (capstone-style claims)
    "deed ledger", "ledger is eternal", "is eternal in the formal sense",
    "no predetermined final", "deed is", "deed ledger is",
    "self-demonstrating closure", "deed is not incomplete",
]

# Markers that identify a statement as a SYSTEM MECHANIC about operation/coherence
# (system-scope governance) rather than a math constant.
_SYSTEM_MECHANIC_MARKERS = [
    "system coherence", "global consistency", "coherence ceiling",
    "coherence violation", "coherence proof", "system robustness",
    "integration depth", "the synthesis graph of deed",
]


def classify_axiom(statement: str) -> Category:
    """Classify a single axiom statement into the correct category.

    CONSTANT     -> a mathematical truth about existence (keep as axiom)
    SYSTEM_RULE  -> self-referential mechanic about the whole system (refile)
    DOMAIN_RULE  -> a mechanic scoped to coherence/synthesis governance (refile)
    """
    s = statement.lower()

    # Specific system-operation mechanics (coherence/synthesis governance) are
    # checked FIRST: these are scoped governance -> Domain rule. Checked before
    # the broad self-reference markers so 'integration depth of DEED' files as a
    # domain rule, not swept up as a generic self-reference.
    for m in _SYSTEM_MECHANIC_MARKERS:
        if m in s:
            return Category.DOMAIN_RULE

    # Self-referential system claims are null as axioms -> System Supreme rules.
    for m in _SYSTEM_SELF_MARKERS:
        if m in s:
            return Category.SYSTEM_RULE

    # Everything else that asserts a measurable/existence property is a CONSTANT.
    return Category.CONSTANT


class AuditReport:
    __slots__ = ("constants", "system_rules", "domain_rules")

    def __init__(self) -> None:
        self.constants: List[Tuple[str, str]] = []      # (new_id, statement)
        self.system_rules: List[Tuple[str, str]] = []   # (orig_ref, statement)
        self.domain_rules: List[Tuple[str, str]] = []    # (orig_ref, statement)

    def summary(self) -> Dict[str, int]:
        return {
            "constants": len(self.constants),
            "system_rules": len(self.system_rules),
            "domain_rules": len(self.domain_rules),
        }


def audit_corpus(corpus: List[Tuple[int, str]]) -> AuditReport:
    """corpus: list of (original_axiom_number, statement). Returns an AuditReport
    with self-referential entries refiled as rules and the true mathematical
    constants renumbered into a clean sequence (C0001, C0002, ...)."""
    report = AuditReport()
    const_seq = 0
    for orig_num, statement in corpus:
        cat = classify_axiom(statement)
        if cat is Category.CONSTANT:
            const_seq += 1
            report.constants.append((f"C{const_seq:04d}", statement))
        elif cat is Category.SYSTEM_RULE:
            report.system_rules.append((f"AX{orig_num}", statement))
        else:
            report.domain_rules.append((f"AX{orig_num}", statement))
    return report


def load_audited_kernel(
    corpus: List[Tuple[int, str]],
    first_principles_trail: List[str],
) -> Tuple[DeedKernel, AuditReport]:
    """Run the audit and load a kernel: true constants committed (TRUE by
    constancy, each carrying the trail to first principles), self-referential
    entries registered as system/domain rules. Enforces separation."""
    report = audit_corpus(corpus)
    k = DeedKernel()
    k.install_governing_rule()

    for cid, statement in report.constants:
        # Each surviving constant carries the trail to first principles. The
        # full per-constant proof is attached by the proof engine later; here
        # the shared root trail anchors them to E(E)=E.
        k.constants.add(Constant(cid, statement, list(first_principles_trail)))

    for rid, statement in report.system_rules:
        k.rules.add_system_rule(SystemRule(rid, statement))

    for rid, statement in report.domain_rules:
        # Coherence/synthesis governance -> domain 45 (Synthesis & Integration)
        k.rules.add_domain_rule(DomainRule(rid, statement, 45))

    k.mark_stable()
    return k, report


# ==============================================================================
# SELF-TEST  — representative sample drawn (in meaning) from the actual 560 set
# ==============================================================================
if __name__ == "__main__":
    # Sample: real mathematical constants vs the self-referential system claims
    # that pepper the 291-560 range of the DEED v1.1 axiom list.
    sample = [
        (3,   "the minimum valid measure of any existing object is strictly greater than zero"),
        (18,  "the empty set does not exist within DEED"),
        (96,  "infinity is not a valid DEED object"),
        (211, "numbers are non-zero integer multiples of the minimum unit epsilon"),
        (291, "DEED is complete within its confirmed domain"),
        (292, "DEED is consistent in the operational sense"),
        (293, "DEED is honest"),
        (296, "DEED is sovereign"),
        (298, "DEED is eternal in the formal sense"),
        (341, "system coherence is the condition in which no proposition is true in one domain and false in another"),
        (347, "the integration depth of DEED is the count of confirmed cross-domain synthesis relationships"),
        (450, "any reasoning system implementing all confirmed DEED axioms satisfies DEED-based cognitive architecture"),
        (560, "the DEED ledger is eternal in the formal sense; it has no predetermined final state"),
    ]

    passed = 0
    failed = []
    def ck(name, cond):
        global passed
        if cond: passed += 1; print(f"  PASS  {name}")
        else: failed.append(name); print(f"  FAIL  {name}")

    print("=" * 70)
    print("  AXIOM AUDIT SELF-TEST — purge self-referential, keep math constants")
    print("=" * 70)

    report = audit_corpus(sample)
    s = report.summary()
    print(f"  classified: {s}")

    # The four genuine math statements must survive as constants.
    const_statements = [c[1] for c in report.constants]
    ck("'measure > 0' kept as constant", any("strictly greater than zero" in c for c in const_statements))
    ck("'empty set does not exist' kept as constant", any("empty set" in c for c in const_statements))
    ck("'infinity not valid' kept as constant", any("infinity is not" in c for c in const_statements))
    ck("'numbers are multiples of epsilon' kept as constant", any("integer multiples" in c for c in const_statements))

    # The self-referential ones must be purged to system rules.
    sys_statements = [r[1] for r in report.system_rules]
    ck("'DEED is complete' refiled as system rule", any("complete" in r for r in sys_statements))
    ck("'DEED is consistent' refiled as system rule", any("consistent" in r for r in sys_statements))
    ck("'DEED is sovereign' refiled as system rule", any("sovereign" in r for r in sys_statements))
    ck("'DEED is eternal' refiled as system rule", any("eternal" in r for r in sys_statements))
    ck("'reasoning system implementing' refiled as system rule", any("reasoning system" in r for r in sys_statements))

    # Coherence/synthesis mechanics -> domain rules.
    dom_statements = [r[1] for r in report.domain_rules]
    ck("'system coherence' refiled as domain rule", any("system coherence" in r for r in dom_statements))
    ck("'integration depth' refiled as domain rule", any("integration depth" in r for r in dom_statements))

    # No self-referential statement survived as a constant.
    ck("NO self-referential statement remained a constant",
       not any("deed is" in c.lower() for c in const_statements))

    # Constants were renumbered into a clean sequence.
    ck("constants renumbered C0001..", report.constants[0][0] == "C0001")

    # Full load into a kernel enforces separation.
    k, rep = load_audited_kernel(sample, ["E(E)=E", "C=N!=0"])
    ck("loaded constants are TRUE by constancy",
       all(c.truth is TruthValue.TRUE for c in k.constants.all()))
    ck("a refiled system rule cannot re-enter as an axiom (it's a rule now)",
       any(r.id.startswith("AX") for r in k.rules.system_rules()))

    print("=" * 70)
    total = passed + len(failed)
    print(f"  {passed}/{total} passed")
    if failed:
        for f_ in failed: print(f"    FAILED: {f_}")
    else:
        print("  AUDIT LOGIC SOUND — ready to run the full 560 corpus")
    print("=" * 70)
    import sys
    sys.exit(0 if not failed else 1)
