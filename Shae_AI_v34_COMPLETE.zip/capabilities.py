#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  capabilities.py
  Coding R&D | Economic Engine
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  On the v34 substrate.

  CODING R&D (kept + enhanced): DEED-native code construction from verified
  primitives, AST-safe structural analysis (no execution of untrusted code),
  and formal verification as a trail-to-first-principles proof obligation.
  Shae builds code by composing confirmed primitives, never by inventing
  unverified constructs.

  ECONOMIC ENGINE (kept + enhanced): income opportunities surfaced THROUGH Shae,
  per the architect's standing rule that Shae should generate income. Monetary
  values are DeedValue (epsilon = 'exists but small'; DomainExit = 'none').
  Sovereign-aware: opportunities are surfaced, never acted on without the
  architect's authority.
================================================================================
"""

from __future__ import annotations

import ast
import time
from typing import Dict, List, Optional

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult, EPSILON,
)
from deed_collections import DeedList, DeedDict

__all__ = ["CodingRnD", "EconomicEngine", "Opportunity"]


# ==============================================================================
# CODING R&D
# ==============================================================================
class CodingRnD:
    """DEED-native code work. Composes from verified primitives; analyzes code
    structurally via AST without executing it; treats verification as a proof
    obligation traced to confirmed building blocks."""

    def __init__(self) -> None:
        # Verified primitive registry: only confirmed building blocks compose.
        self._primitives: DeedDict = DeedDict()
        self._seed_primitives()

    def _seed_primitives(self) -> None:
        for name, desc in [
            ("guard_floor", "reject sub-floor values (C=N!=0)"),
            ("four_value_return", "return TRUE/FALSE/UNKNOWN/PROBE, never a bare bool"),
            ("domain_exit_on_absence", "return DomainExit, never None"),
            ("trail_record", "attach a derivation trail to every result"),
            ("sovereign_gate", "gate state-changing actions on architect authority"),
        ]:
            self._primitives.set(name, desc)

    def analyze(self, source: str) -> DeedResult:
        """Structural analysis via AST. Never executes. Reports parse validity
        and a count of definitions -- a safe, offline static read."""
        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes=f"syntax error: {e}")
        funcs = sum(1 for n in ast.walk(tree) if isinstance(n, ast.FunctionDef))
        classes = sum(1 for n in ast.walk(tree) if isinstance(n, ast.ClassDef))
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(max(funcs + classes, EPSILON)),
                          notes=f"parsed: {funcs} functions, {classes} classes (static, not executed)")

    def construct(self, spec: str, primitives_used: List[str]) -> DeedResult:
        """Compose code from VERIFIED primitives only. A primitive not in the
        registry is unverified -> the construction is held UNKNOWN (not invented
        in). Follows the 'never invent, only compose confirmed' discipline."""
        unverified = [p for p in primitives_used if not self._primitives.has(p)]
        if unverified:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes=f"construction held: unverified primitives {unverified} "
                                    "(compose only from confirmed building blocks)")
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(max(len(primitives_used), EPSILON)),
                          notes=f"constructed from {len(primitives_used)} verified primitives: {spec}")

    def verify(self, claim_about_code: str, proof_trail: List[str]) -> DeedResult:
        """Verification as a proof obligation: a code property is confirmed iff
        its trail reaches confirmed primitives. No trail -> UNKNOWN."""
        if len(proof_trail) == 0:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes="no proof trail; property UNKNOWN (not asserted)")
        grounded = all(step in self._primitives or step in ("E(E)=E", "C=N!=0")
                       for step in proof_trail)
        if grounded:
            return DeedResult(truth=TruthValue.TRUE, notes=f"verified: {claim_about_code}")
        return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                          notes="proof trail does not reach confirmed primitives")


# ==============================================================================
# ECONOMIC ENGINE
# ==============================================================================
class Opportunity:
    __slots__ = ("name", "description", "est_value", "channel", "sovereign_required")

    def __init__(self, name: str, description: str, est_value: float, channel: str,
                 sovereign_required: bool = True) -> None:
        self.name = name
        self.description = description
        # Monetary value as DeedValue: floored. A real opportunity has at least
        # floor value; 'no opportunity' is DomainExit, not a 0-value entry.
        self.est_value = DeedValue(max(est_value, EPSILON))
        self.channel = channel
        self.sovereign_required = sovereign_required

    def __repr__(self) -> str:
        return f"Opportunity({self.name}: ~{self.est_value.value:g} via {self.channel})"


class EconomicEngine:
    """Surfaces income opportunities through Shae. Sovereign-aware: opportunities
    are surfaced and ranked; acting on them requires the architect's authority."""

    def __init__(self) -> None:
        self._opportunities: DeedList = DeedList()
        self._seed()

    def _seed(self) -> None:
        # Eight seeded opportunity classes Shae can pursue / surface.
        for opp in [
            Opportunity("deed_audit_services", "Formal DEED-trail audits of others' systems/claims", 500, "direct"),
            Opportunity("proof_generation", "Trail-to-first-principles proof generation as a service", 300, "direct"),
            Opportunity("sovereign_agent_licensing", "License a sovereign offline agent build", 1000, "licensing"),
            Opportunity("persona_companion_sales", "Companion module subscriptions", 20, "subscription"),
            Opportunity("coding_rnd_contract", "DEED-native code construction contracts", 800, "contract"),
            Opportunity("compute_broker", "Broker idle local compute for verified workloads", 50, "marketplace"),
            Opportunity("content_substack", "Writing on DEED / sovereign AI (Substack/YouTube/X)", 100, "content"),
            Opportunity("teaching_first_principles", "Teach DEED first-principles reasoning", 150, "education"),
        ]:
            self._opportunities.append(opp)

    def opportunities(self) -> List[Opportunity]:
        return list(self._opportunities)

    def ranked(self) -> List[Opportunity]:
        """Rank by estimated value (descending). All values are floored DeedValues."""
        return sorted(self._opportunities, key=lambda o: o.est_value.value, reverse=True)

    def surface_best(self, n: int = 3) -> DeedResult:
        top = self.ranked()[:max(1, n)]
        names = ", ".join(o.name for o in top)
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(max(len(top), EPSILON)),
                          notes=f"top income paths through Shae: {names} (sovereign approval to act)")

    def pursue(self, name: str, authorize: Optional[bool] = None) -> DeedResult:
        """Acting on an opportunity is sovereign-gated."""
        match = next((o for o in self._opportunities if o.name == name), None)
        if match is None:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes=f"no opportunity named {name!r}")
        if match.sovereign_required and not authorize:
            return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                              notes=f"'{name}' requires sovereign authorization before action")
        return DeedResult(truth=TruthValue.TRUE, value=match.est_value,
                          notes=f"pursuing '{name}' (~{match.est_value.value:g} via {match.channel})")
