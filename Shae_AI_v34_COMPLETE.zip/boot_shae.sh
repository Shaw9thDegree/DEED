#!/usr/bin/env bash
# SHAE AI v34.0 — boot script. Extracts/runs in dependency order.
# Usage: bash boot_shae.sh   (or: python3 launcher.py)
echo "Booting Shae AI v34.0 (DEED-Native)..."
python3 launcher.py
