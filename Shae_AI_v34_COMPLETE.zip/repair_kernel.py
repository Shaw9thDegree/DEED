#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  repair_kernel.py
  Self-diagnosis | Self-repair | Floor reinforcement | 1=1 trail-integrity watch
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  On the v34 substrate.

  The repair kernel is DEED's R-operation made operational: on a confirmed fault
  or contradiction, isolate it (PROBE), re-derive from the nearest confirmed
  ground, and continue -- a fault in one place never collapses the system.

  THE WEAKEST-CLAIM GUARD (architect, this build):
    1=1 is DEED's weakest load-bearing claim, and its vulnerability is identity
    EROSION ALONG THE TRAIL -- local identity holding at each step does not
    guarantee global identity from origin to claim. So Law 3 (Identity Stability)
    is implemented here as a TRAIL-INTEGRITY check (origin-to-claim), with EXACT
    equality (drift surfaces as inequality, never hides under tolerance), and the
    repair kernel watches this claim hardest.
================================================================================
"""

from __future__ import annotations

import time
from typing import Callable, Dict, List, Optional

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult, EPSILON,
)
from deed_collections import DeedList, DeedDict

__all__ = [
    "Fault", "FaultRegistry", "DiagnosticEngine", "SelfRepairEngine",
    "IdentityTrailWatch", "RepairKernel",
]


# ==============================================================================
# FAULT + REGISTRY
# ==============================================================================
class Fault:
    __slots__ = ("source", "description", "severity", "at", "repaired")

    def __init__(self, source: str, description: str, severity: TruthValue) -> None:
        self.source = source
        self.description = description
        # severity rides the four-value truth: PROBE = isolate/investigate,
        # FALSE = confirmed broken. (No severity-0; absence of fault isn't a fault.)
        self.severity = severity
        self.at = time.time()
        self.repaired = False

    def __repr__(self) -> str:
        return f"Fault({self.source}: {self.description}, {self.severity.value}, repaired={self.repaired})"


class FaultRegistry:
    def __init__(self) -> None:
        self._faults: DeedList = DeedList()

    def record(self, fault: Fault) -> DeedResult:
        self._faults.append(fault)
        return DeedResult(truth=TruthValue.TRUE, notes=f"fault recorded: {fault.description}")

    def open_faults(self) -> List[Fault]:
        return [f for f in self._faults if not f.repaired]

    def count(self) -> DeedValue:
        return self._faults.count()


# ==============================================================================
# DIAGNOSTIC ENGINE — checks subsystems, reinforces the floor at runtime
# ==============================================================================
class DiagnosticEngine:
    def __init__(self, registry: FaultRegistry) -> None:
        self.registry = registry

    def floor_reinforcement(self, value) -> DeedResult:
        """C=N!=0 enforced at runtime: any live value found below the floor is a
        confirmed fault (it has slipped toward non-existence). Reinforce."""
        v = value.value if isinstance(value, DeedValue) else float(value)
        if v < EPSILON:
            self.registry.record(Fault("floor", f"value {v} slipped below floor", TruthValue.FALSE))
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes="floor breach reinforced: value re-grounded to existence boundary")
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(v), notes="floor intact")

    def diagnose(self, subsystem: str, healthy: bool, detail: str = "") -> DeedResult:
        if healthy:
            return DeedResult(truth=TruthValue.TRUE, notes=f"{subsystem} nominal")
        self.registry.record(Fault(subsystem, detail or "subsystem unhealthy", TruthValue.PROBE))
        return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                          notes=f"{subsystem} fault isolated for repair (PROBE)")


# ==============================================================================
# IDENTITY TRAIL WATCH — the 1=1 weakest-claim guard
# ==============================================================================
class IdentityTrailWatch:
    """Law 3 (Identity Stability) as a TRAIL-INTEGRITY check. Verifies that a
    claim's identity holds from ORIGIN to claim across the whole trail -- not
    merely step-to-step -- using EXACT equality so any drift surfaces rather
    than hiding under tolerance. This is the guard on DEED's weakest claim."""

    def __init__(self, registry: FaultRegistry) -> None:
        self.registry = registry

    def verify_trail(self, trail: List[float]) -> DeedResult:
        """A trail is a sequence of identity-bearing values from origin to claim.
        Integrity holds iff every link equals the origin EXACTLY (1=1 preserved
        the whole way). Any inequality = identity erosion = fault."""
        if len(trail) == 0:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes="empty trail: identity cannot be verified (ungrounded)")
        origin = trail[0]
        for i, link in enumerate(trail[1:], start=1):
            if link != origin:  # EXACT equality; no tolerance band
                self.registry.record(Fault(
                    "identity", f"1=1 erosion at trail step {i}: {link} != origin {origin}",
                    TruthValue.FALSE))
                return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                                  notes=f"identity erosion detected at step {i} "
                                        f"(global 1=1 broke though local steps held)")
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(len(trail)),
                          notes="identity stable origin-to-claim (1=1 held across the whole trail)")


# ==============================================================================
# SELF-REPAIR ENGINE — R-operation: isolate, re-derive, continue
# ==============================================================================
class SelfRepairEngine:
    def __init__(self, registry: FaultRegistry) -> None:
        self.registry = registry

    def repair(self, fault: Fault, rederive: Optional[Callable[[], DeedResult]] = None) -> DeedResult:
        """R-operation. Isolate the fault (already PROBE/FALSE), re-derive from
        the nearest confirmed ground if a re-derivation is supplied, and mark
        repaired. A fault never collapses the system; it is quarantined."""
        if rederive is not None:
            result = rederive()
            if result.truth is TruthValue.TRUE:
                fault.repaired = True
                return DeedResult(truth=TruthValue.TRUE,
                                  notes=f"repaired '{fault.description}' via re-derivation from ground")
            return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                              notes=f"re-derivation did not confirm; '{fault.description}' held in PROBE")
        # No re-derivation available: isolate and hold (quarantine, not collapse).
        return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                          notes=f"'{fault.description}' isolated; system continues (quarantined)")


# ==============================================================================
# REPAIR KERNEL — ties registry + diagnostics + identity-watch + repair
# ==============================================================================
class RepairKernel:
    def __init__(self) -> None:
        self.registry = FaultRegistry()
        self.diagnostics = DiagnosticEngine(self.registry)
        self.identity = IdentityTrailWatch(self.registry)
        self.repair = SelfRepairEngine(self.registry)

    def self_check(self, subsystems: Dict[str, bool]) -> DeedResult:
        """Run a health pass over named subsystems. Returns TRUE if all nominal,
        PROBE if any fault was isolated (system continues regardless)."""
        any_fault = False
        for name, healthy in subsystems.items():
            r = self.diagnostics.diagnose(name, healthy)
            if r.truth is not TruthValue.TRUE:
                any_fault = True
        if any_fault:
            return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                              notes=f"{len(self.registry.open_faults())} fault(s) isolated; system continues")
        return DeedResult(truth=TruthValue.TRUE, notes="all subsystems nominal")

    def watch_identity(self, trail: List[float]) -> DeedResult:
        """The weakest-claim guard, surfaced at kernel level: verify 1=1 holds
        across a derivation trail origin-to-claim."""
        return self.identity.verify_trail(trail)
