#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34  —  LAYER 1  —  deed_collections.py
  Collections built from the primitives substrate.
--------------------------------------------------------------------------------
  WHY THIS LAYER EXISTS
  ---------------------
  Python's list, dict, set conflate "empty" with "non-existent". Both are
  falsy; both `len()==0`; a missing key returns None just like a key mapped
  to None. DEED forbids that conflation:

      * A collection IN THE DOMAIN is real. It may hold no elements right now,
        but it EXISTS and can be queried. Its count is a DeedValue at the floor
        (the minimum measurable state of "a real but currently-empty domain"),
        never literal 0.
      * A collection that has EXITED is no longer a thing to query. Accessing
        it raises DomainExit. The question dissolved.

  `if collection:` is forbidden across the codebase. Use `.has_elements()`.
================================================================================
"""

from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional, Tuple

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult,
    EPSILON, is_exit,
)

__all__ = ["DeedList", "DeedDict", "DeedSet"]


class _DomainBacked:
    """Shared domain-membership machinery: a collection is either IN the domain
    (real, queryable, possibly empty) or has EXITED (queries raise)."""

    __slots__ = ("_in_domain",)

    def __init__(self) -> None:
        self._in_domain: bool = True

    @property
    def in_domain(self) -> bool:
        return self._in_domain

    def exit_domain(self) -> None:
        """Transition this collection out of the domain. After this, queries
        raise DomainExit. This is NOT 'clear' -- the collection ceases to be a
        thing to query at all."""
        self._in_domain = False

    def _guard(self) -> None:
        if not self._in_domain:
            raise DomainExitError("collection has exited the domain (no longer queryable)")

    def has_elements(self) -> bool:
        """The DEED-correct replacement for `if collection:`. True iff in the
        domain AND holding at least one real element."""
        raise NotImplementedError


class DeedList(_DomainBacked):
    """An ordered collection that distinguishes empty-but-real from exited."""

    __slots__ = ("_items",)

    def __init__(self, items: Optional[List[Any]] = None) -> None:
        super().__init__()
        self._items: List[Any] = list(items) if items is not None else []

    def append(self, item: Any) -> None:
        self._guard()
        if item is None:
            raise DomainExitError("cannot store None in a DeedList (absence is not an element)")
        self._items.append(item)

    def extend(self, items: Any) -> None:
        for it in items:
            self.append(it)

    def get(self, index: int) -> Any:
        """Index access. Out-of-range returns DomainExit (not IndexError, not
        None) -- the element is absent, the question dissolves."""
        self._guard()
        if -len(self._items) <= index < len(self._items):
            return self._items[index]
        return DomainExit

    def count(self) -> DeedValue:
        """Count as a DeedValue. An empty-but-real list reports the floor (it
        exists; it has the minimum measurable presence), never 0."""
        self._guard()
        n = len(self._items)
        return DeedValue(n if n > 0 else EPSILON)

    @property
    def raw_len(self) -> int:
        """The literal element count for iteration logic. May be 0 for an
        empty-but-real list -- use only where you have already guarded domain
        membership and need the integer, not the DeedValue measure."""
        self._guard()
        return len(self._items)

    def has_elements(self) -> bool:
        return self._in_domain and len(self._items) > 0

    def __iter__(self) -> Iterator[Any]:
        self._guard()
        return iter(self._items)

    def __len__(self) -> int:
        self._guard()
        return len(self._items)

    def __getitem__(self, index: int) -> Any:
        result = self.get(index)
        if is_exit(result):
            raise DomainExitError(f"index {index} absent from DeedList")
        return result

    def __repr__(self) -> str:
        if not self._in_domain:
            return "DeedList(EXITED)"
        return f"DeedList({self._items!r})"


class DeedDict(_DomainBacked):
    """A mapping where a missing key returns DomainExit (never None), and where
    the dict itself can exit the domain."""

    __slots__ = ("_data",)

    def __init__(self, data: Optional[Dict[Any, Any]] = None) -> None:
        super().__init__()
        self._data: Dict[Any, Any] = {}
        if data is not None:
            for k, v in data.items():
                self.set(k, v)

    def set(self, key: Any, value: Any) -> None:
        self._guard()
        if key is None:
            raise DomainExitError("cannot use None as a DeedDict key")
        if value is None:
            raise DomainExitError("cannot store None as a DeedDict value")
        self._data[key] = value

    def get(self, key: Any) -> Any:
        """Miss returns the DomainExit sentinel, NOT None. Canonical check on
        the result is `is_exit(result)`."""
        self._guard()
        return self._data.get(key, DomainExit)

    def has(self, key: Any) -> bool:
        self._guard()
        return key in self._data

    def remove(self, key: Any) -> DeedResult:
        self._guard()
        if key in self._data:
            del self._data[key]
            return DeedResult(truth=TruthValue.TRUE, notes=f"removed {key!r}")
        return DeedResult(truth=TruthValue.FALSE, notes=f"key {key!r} absent")

    def keys(self) -> List[Any]:
        self._guard()
        return list(self._data.keys())

    def values(self) -> List[Any]:
        self._guard()
        return list(self._data.values())

    def items(self) -> List[Tuple[Any, Any]]:
        self._guard()
        return list(self._data.items())

    def count(self) -> DeedValue:
        self._guard()
        n = len(self._data)
        return DeedValue(n if n > 0 else EPSILON)

    def has_elements(self) -> bool:
        return self._in_domain and len(self._data) > 0

    def __getitem__(self, key: Any) -> Any:
        result = self.get(key)
        if is_exit(result):
            raise DomainExitError(f"key {key!r} absent from DeedDict")
        return result

    def __setitem__(self, key: Any, value: Any) -> None:
        self.set(key, value)

    def __contains__(self, key: Any) -> bool:
        return self.has(key)

    def __iter__(self) -> Iterator[Any]:
        self._guard()
        return iter(self._data)

    def __len__(self) -> int:
        self._guard()
        return len(self._data)

    def __repr__(self) -> str:
        if not self._in_domain:
            return "DeedDict(EXITED)"
        return f"DeedDict({self._data!r})"


class DeedSet(_DomainBacked):
    """A set distinguishing empty-but-real from exited; rejects None members."""

    __slots__ = ("_items",)

    def __init__(self, items: Optional[Any] = None) -> None:
        super().__init__()
        self._items: set = set()
        if items is not None:
            for it in items:
                self.add(it)

    def add(self, item: Any) -> None:
        self._guard()
        if item is None:
            raise DomainExitError("cannot add None to a DeedSet")
        self._items.add(item)

    def has(self, item: Any) -> bool:
        self._guard()
        return item in self._items

    def discard(self, item: Any) -> DeedResult:
        self._guard()
        if item in self._items:
            self._items.discard(item)
            return DeedResult(truth=TruthValue.TRUE, notes="discarded")
        return DeedResult(truth=TruthValue.FALSE, notes="member absent")

    def count(self) -> DeedValue:
        self._guard()
        n = len(self._items)
        return DeedValue(n if n > 0 else EPSILON)

    def has_elements(self) -> bool:
        return self._in_domain and len(self._items) > 0

    def union(self, other: "DeedSet") -> "DeedSet":
        self._guard()
        return DeedSet(self._items | other._items)

    def intersection(self, other: "DeedSet") -> "DeedSet":
        self._guard()
        return DeedSet(self._items & other._items)

    def __contains__(self, item: Any) -> bool:
        return self.has(item)

    def __iter__(self) -> Iterator[Any]:
        self._guard()
        return iter(self._items)

    def __len__(self) -> int:
        self._guard()
        return len(self._items)

    def __repr__(self) -> str:
        if not self._in_domain:
            return "DeedSet(EXITED)"
        return f"DeedSet({self._items!r})"
