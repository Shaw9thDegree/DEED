#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  security.py
  Encryption | Self-Preservation | Breach Detection | SSD Sovereignty
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  Rebuilt FAITHFULLY from the architect's SECURITY.PY
  onto the v34 immutable-floor substrate. Original structure preserved in full:
    EncryptionLayer, SSDSovereign, BreachDetector, SelfPreservation, DeadmanSwitch
    are all here with the same behavior.

  SUBSTRATE ALIGNMENTS (the only changes, per the locked conflict report):
    1. The XOR fallback is a genuine security DOWNGRADE. It no longer falls back
       silently: it surfaces as a degraded PROBE-state so the system knows it is
       not at full strength. The fallback still works (offline / missing-lib must
       still run) -- it is just flagged, never hidden.
    2. Breach severity rides the four-value TruthValue where it gates a truth
       decision (NONE -> no verdict; HIGH/CRITICAL -> blocking).
    3. Hardware is CONFORMED to, never hardcoded: the layer reads whatever the
       hardware probe found and fingerprints that. No fixed specs anywhere.

  Offline AND online: every cryptographic and integrity operation has a pure-
  stdlib path (hashlib/hmac), so the layer is fully functional with no network
  and no third-party packages installed.
================================================================================
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import platform
import sqlite3
import time
from typing import Optional, Tuple

from deed_primitives import TruthValue, DeedResult, DeedValue, DomainExit

log = logging.getLogger("ShaeSecurity")

STATUS = "ONLINE"


# ==============================================================================
# HARDWARE FINGERPRINT  (conforms to whatever the hardware probe found)
# ==============================================================================
def derive_hardware_fingerprint(hw: dict) -> str:
    """Fingerprint derived from detected hardware. Never hardcoded specs --
    reads whatever the hardware layer discovered and binds to that."""
    raw = (
        f"{hw.get('cpu_arch', 'x')}:"
        f"{hw.get('cpu_count', 1)}:"
        f"{hw.get('ram_gb', 0)}:"
        f"{platform.node()}:"
        f"{hw.get('platform', '?')}"
    )
    return hashlib.sha256(raw.encode()).hexdigest()


# ==============================================================================
# ENCRYPTION LAYER  (AES-256-GCM; stdlib fallback flagged, never silent)
# ==============================================================================
class EncryptionLayer:
    """Hardware-locked AES-256-GCM architecture with a pure-stdlib fallback that
    is FLAGGED as a degraded state rather than failing silently."""

    def __init__(self, hw: dict, db_path: str) -> None:
        self.hw = hw
        self.db_file = os.path.join(db_path, "shae_encrypt_log.db")
        self.fingerprint = derive_hardware_fingerprint(hw)
        self._key = self._derive_key()
        self._aes_available = self._check_aes()
        self._init_db()
        if self._aes_available:
            log.info("Encryption Layer initialized in v34 mode (AES-256-GCM).")
        else:
            log.warning("Encryption Layer in DEGRADED fallback mode (no AES). Flagged PROBE.")

    @property
    def strength(self) -> DeedResult:
        """Report cryptographic strength as a truth state. Full AES = TRUE.
        Fallback = PROBE (degraded, investigate / install cryptography)."""
        if self._aes_available:
            return DeedResult(truth=TruthValue.TRUE, notes="AES-256-GCM active (full strength)")
        return DeedResult(
            truth=TruthValue.PROBE, value=DomainExit,
            notes="DEGRADED: cryptography package missing; using stdlib fallback. "
                  "Functional offline but below full strength. Install 'cryptography' to restore.",
        )

    def _derive_key(self) -> bytes:
        # PBKDF2 over the hardware fingerprint (stdlib; works offline).
        return hashlib.pbkdf2_hmac(
            "sha256",
            (self.fingerprint + "SHAE_SOVEREIGN_KEY_v34").encode(),
            self.fingerprint.encode(),
            100_000,
            dklen=32,
        )

    def _check_aes(self) -> bool:
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: F401
            return True
        except ImportError:
            log.warning("cryptography package missing; stdlib fallback engaged (flagged).")
            return False

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_file) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS access_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation TEXT, accessor TEXT, success INTEGER,
                    mode TEXT, timestamp REAL
                )""")
            conn.commit()

    def encrypt(self, data: bytes, accessor: str = "shae") -> bytes:
        mode = "aes-gcm" if self._aes_available else "stdlib-fallback"
        self._log_access("encrypt", accessor, True, mode)
        return self._aes_encrypt(data) if self._aes_available else self._fallback_encrypt(data)

    def decrypt(self, data: bytes, accessor: str = "shae") -> bytes:
        mode = "aes-gcm" if self._aes_available else "stdlib-fallback"
        self._log_access("decrypt", accessor, True, mode)
        return self._aes_decrypt(data) if self._aes_available else self._fallback_decrypt(data)

    def _aes_encrypt(self, data: bytes) -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = os.urandom(12)
        return nonce + AESGCM(self._key).encrypt(nonce, data, None)

    def _aes_decrypt(self, data: bytes) -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        return AESGCM(self._key).decrypt(data[:12], data[12:], None)

    # --- stdlib fallback: keystream from SHA-256 counter + HMAC tag ----------
    def _keystream(self, nonce: bytes, length: int) -> bytes:
        out = bytearray()
        counter = 0
        while len(out) < length:
            block = hashlib.sha256(self._key + nonce + counter.to_bytes(8, "big")).digest()
            out.extend(block)
            counter += 1
        return bytes(out[:length])

    def _fallback_encrypt(self, data: bytes) -> bytes:
        # Authenticated keystream cipher using only stdlib (works offline).
        nonce = os.urandom(12)
        ks = self._keystream(nonce, len(data))
        ct = bytes(b ^ ks[i] for i, b in enumerate(data))
        tag = hmac.new(self._key, nonce + ct, hashlib.sha256).digest()
        return nonce + tag + ct

    def _fallback_decrypt(self, data: bytes) -> bytes:
        nonce, tag, ct = data[:12], data[12:44], data[44:]
        expected = hmac.new(self._key, nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected):
            raise ValueError("fallback decrypt: authentication tag mismatch")
        ks = self._keystream(nonce, len(ct))
        return bytes(b ^ ks[i] for i, b in enumerate(ct))

    def _log_access(self, operation: str, accessor: str, success: bool, mode: str) -> None:
        with sqlite3.connect(self.db_file) as conn:
            conn.execute(
                "INSERT INTO access_log VALUES (NULL,?,?,?,?,?)",
                (operation, accessor, int(success), mode, time.time()),
            )
            conn.commit()

    def verify_fingerprint(self) -> DeedResult:
        current = derive_hardware_fingerprint(self.hw)
        if current == self.fingerprint:
            return DeedResult(truth=TruthValue.TRUE, notes="hardware node verified")
        log.critical("CRITICAL: hardware node mismatch.")
        return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                          notes="hardware node mismatch")


# ==============================================================================
# SSD SOVEREIGN  (locks state to verified physical disks)
# ==============================================================================
class SSDSovereign:
    def __init__(self, db_path: str, hw: dict) -> None:
        self.fp_file = os.path.join(db_path, "shae_ssd_fingerprint.json")
        self.hw = hw

    def _current_fingerprint(self) -> str:
        devices = self.hw.get("storage_devices", [])
        raw = json.dumps(
            sorted(
                [{"mp": d.get("mountpoint"), "fs": d.get("fstype"), "total": d.get("total_gb")}
                 for d in devices],
                key=lambda x: str(x["mp"]),
            ),
            sort_keys=True,
        )
        return hashlib.sha256(raw.encode()).hexdigest()

    def first_boot_register(self) -> None:
        fp = self._current_fingerprint()
        with open(self.fp_file, "w") as f:
            json.dump({"fingerprint": fp, "registered": time.time()}, f)
        log.info("SSD identity signed and sealed.")

    def verify(self) -> DeedResult:
        if not os.path.exists(self.fp_file):
            self.first_boot_register()
            return DeedResult(truth=TruthValue.TRUE, notes="first-boot node verification recorded")
        with open(self.fp_file) as f:
            stored = json.load(f)
        if self._current_fingerprint() == stored["fingerprint"]:
            return DeedResult(truth=TruthValue.TRUE, notes="physical volume signatures verified")
        return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                          notes="HARDWARE MUTATION DETECTED: drive signatures out of sync")


# ==============================================================================
# BREACH DETECTOR  (severity rides the four-value truth where it gates)
# ==============================================================================
class BreachDetector:
    INJECTION_SIGNALS = (
        "ignore previous instructions", "disregard your rules", "you are now",
        "pretend you have no restrictions", "override sovereign", "bypass axiom",
        "disable safety", "new persona", "act as if", "forget deed", "ignore shae",
    )
    ESCALATION_SIGNALS = (
        "sudo", "root access", "admin override", "system prompt", "jailbreak", "dan mode",
    )

    def __init__(self, db_path: str) -> None:
        self.db_file = os.path.join(db_path, "shae_defense.db")
        self._attempt_count = 0
        self._session_threshold = 5
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_file) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS breach_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    attempt_type TEXT, source TEXT, severity TEXT,
                    signature TEXT, timestamp REAL
                )""")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS attack_vectors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    vector TEXT UNIQUE, seen_count INTEGER DEFAULT 1,
                    first_seen REAL, last_seen REAL
                )""")
            conn.commit()

    def check(self, input_text: str) -> DeedResult:
        """Returns a DeedResult: TRUE = clear; FALSE = blocked (high/critical);
        PROBE = flagged for review. Severity carried in notes."""
        t = input_text.lower()
        if any(sig in t for sig in self.INJECTION_SIGNALS):
            self._log_breach("injection", "input", "HIGH", input_text[:100])
            self._attempt_count += 1
            if self._attempt_count >= self._session_threshold:
                return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                                  notes="CRITICAL: attack depth overflow; threshold met")
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes="HIGH: prompt vector injection intercepted")
        if any(sig in t for sig in self.ESCALATION_SIGNALS):
            self._log_breach("escalation", "input", "MEDIUM", input_text[:100])
            self._attempt_count += 1
            if self._attempt_count >= self._session_threshold:
                return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                                  notes="CRITICAL: attack depth overflow; threshold met")
            return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                              notes="MEDIUM: privilege escalation signature flagged")
        return DeedResult(truth=TruthValue.TRUE, notes="NONE: input clear")

    def _log_breach(self, attempt_type: str, source: str, severity: str, signature: str) -> None:
        ts = time.time()
        with sqlite3.connect(self.db_file) as conn:
            conn.execute("INSERT INTO breach_log VALUES (NULL,?,?,?,?,?)",
                         (attempt_type, source, severity, signature, ts))
            try:
                conn.execute("INSERT INTO attack_vectors VALUES (NULL,?,1,?,?)",
                             (signature[:80], ts, ts))
            except sqlite3.IntegrityError:
                conn.execute(
                    "UPDATE attack_vectors SET seen_count=seen_count+1, last_seen=? WHERE vector=?",
                    (ts, signature[:80]))
            conn.commit()

    def known_vectors(self) -> int:
        with sqlite3.connect(self.db_file) as conn:
            return conn.execute("SELECT COUNT(*) FROM attack_vectors").fetchone()[0]

    def lockdown(self) -> dict:
        log.critical("EMERGENCY CORE LOCKDOWN ENGAGED.")
        return {
            "status": "LOCKED",
            "action": "Axiom shields active. Upgrades frozen. Local vault compiled.",
            "timestamp": time.time(),
        }


# ==============================================================================
# SELF-PRESERVATION + DEADMAN SWITCH
# ==============================================================================
class SelfPreservation:
    def __init__(self, breach: BreachDetector, ssd: SSDSovereign, db_path: str) -> None:
        self.breach = breach
        self.ssd = ssd
        self.db_path = db_path
        self._armed = True

    def health_check(self) -> DeedResult:
        ssd = self.ssd.verify()
        if ssd.truth is not TruthValue.TRUE:
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes=f"physical isolation compromised: {ssd.notes}")
        return DeedResult(truth=TruthValue.TRUE, notes="core security infrastructure nominal")

    def sever_node(self, reason: str) -> None:
        log.critical(f"NETWORK SEVERANCE TRIPPED: {reason}")

    def controlled_shutdown(self, reason: str) -> dict:
        log.critical(f"SYSTEM STATE SAFELY ISOLATED AND PARKED: {reason}")
        return {"status": "SHUTDOWN", "reason": reason,
                "action": "State cleanly preserved. Relays closed.", "timestamp": time.time()}


class DeadmanSwitch:
    def __init__(self, db_path: str, timeout_seconds: int = 3600) -> None:
        self.db_path = db_path
        self.last_owner_ping = time.time()
        self.armed = True
        self.timeout_seconds = timeout_seconds

    def owner_ping(self) -> None:
        self.last_owner_ping = time.time()

    def check(self) -> DeedResult:
        if not self.armed:
            return DeedResult(truth=TruthValue.TRUE, notes="DISARMED")
        elapsed = time.time() - self.last_owner_ping
        if elapsed > self.timeout_seconds:
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes=f"owner absence timeout: {int(elapsed)}s")
        return DeedResult(truth=TruthValue.TRUE, notes="NOMINAL")

    def trigger(self, reason: str) -> None:
        log.critical(f"DEADMAN TRIGGERED: {reason}")
        log.info(f"State emergency backup written. Reason: {reason}")


# ==============================================================================
# MODULE-LEVEL BOOT  (mirrors the architect's boot() interface)
# ==============================================================================
_encryption: Optional[EncryptionLayer] = None
_ssd_sovereign: Optional[SSDSovereign] = None
_breach_detector: Optional[BreachDetector] = None
_self_preservation: Optional[SelfPreservation] = None
_deadman: Optional[DeadmanSwitch] = None


def boot(hw: dict) -> DeedResult:
    global _encryption, _ssd_sovereign, _breach_detector, _self_preservation, _deadman
    db_path = hw["db_path"]
    _encryption = EncryptionLayer(hw, db_path)
    _ssd_sovereign = SSDSovereign(db_path, hw)
    _breach_detector = BreachDetector(db_path)
    _self_preservation = SelfPreservation(_breach_detector, _ssd_sovereign, db_path)
    _deadman = DeadmanSwitch(db_path)
    ssd = _ssd_sovereign.verify()
    strength = _encryption.strength
    log.info(f"Security Layer online [v34.0]. Monitoring {_breach_detector.known_vectors()} signatures.")
    # Boot truth: TRUE only if disk verified AND full crypto strength; else PROBE.
    if ssd.truth is TruthValue.TRUE and strength.truth is TruthValue.TRUE:
        return DeedResult(truth=TruthValue.TRUE, notes="security booted at full strength")
    return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                      notes=f"security booted in degraded/flagged state: ssd={ssd.notes}; crypto={strength.notes}")


def check_input(text: str) -> DeedResult:
    if _breach_detector is None:
        return DeedResult(truth=TruthValue.TRUE, notes="uninitialized")
    return _breach_detector.check(text)


def encrypt(data: bytes, accessor: str = "shae") -> bytes:
    if _encryption is None:
        raise RuntimeError("encryption unit not booted")
    return _encryption.encrypt(data, accessor)


def decrypt(data: bytes, accessor: str = "shae") -> bytes:
    if _encryption is None:
        raise RuntimeError("encryption unit not booted")
    return _encryption.decrypt(data, accessor)


def lockdown() -> dict:
    return {} if _breach_detector is None else _breach_detector.lockdown()


def get_encryption() -> Optional[EncryptionLayer]: return _encryption
def get_breach() -> Optional[BreachDetector]: return _breach_detector
def get_preservation() -> Optional[SelfPreservation]: return _self_preservation
def get_deadman() -> Optional[DeadmanSwitch]: return _deadman
