#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  launcher.py
  THE ENTRY POINT  —  run this to boot and talk to Shae
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  Fully offline. Sovereignty under the architect.

  Usage:   python3 launcher.py
  Commands: /sovereign /repair /diagnose /deed /income /status /menu /exit /help
================================================================================
"""

from __future__ import annotations

import sys

from shae_engine import ShaeEngine, VERSION, CODENAME
from deed_primitives import TruthValue


BANNER = f"""
================================================================================
  SHAE AI {VERSION}  —  {CODENAME}
  Sovereign · Offline · DEED-native · C = N != 0
  Architect: Jarad Shaw
================================================================================
"""

HELP = """
  Commands:
    /sovereign [on|off]  — toggle sovereign authorization (architect only)
    /status              — full system status
    /diagnose            — run a self-check across subsystems
    /repair              — show open faults / repair state
    /deed                — show constants & rules summary
    /income              — surface top income paths through Shae
    /companion [on|off]  — toggle companion module
    /menu                — list commands
    /help                — this help
    /exit                — shut down cleanly
  Anything else is treated as input for Shae to reason about.
"""


def run() -> None:
    print(BANNER)
    shae = ShaeEngine(architect="Jarad Shaw")
    boot = shae.boot()
    print(f"  Boot: {boot.truth.value} — {boot.notes}\n")
    print("  Type /help for commands. Type /exit to quit.\n")

    while True:
        try:
            line = input("you > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Shutting down cleanly. State preserved.")
            break
        if not line:
            continue

        if line.startswith("/"):
            parts = line.split()
            cmd = parts[0].lower()
            arg = parts[1].lower() if len(parts) > 1 else ""

            if cmd == "/exit":
                print("  Shutting down cleanly. State preserved.")
                break
            elif cmd in ("/help", "/menu"):
                print(HELP)
            elif cmd == "/sovereign":
                on = arg != "off"
                shae.sovereign_authorize(on)
                print(f"  sovereign authorization: {'ON' if on else 'OFF'}")
            elif cmd == "/status":
                for k, v in shae.status().items():
                    print(f"    {k}: {v}")
            elif cmd == "/diagnose":
                r = shae.repair.self_check({
                    "core": True, "security": shae.security_boot.truth is not TruthValue.FALSE,
                    "lattice": shae.lattice.emerged, "mods": True})
                print(f"    {r.truth.value} — {r.notes}")
            elif cmd == "/repair":
                faults = shae.repair.registry.open_faults()
                print(f"    open faults: {len(faults)}")
                for f in faults:
                    print(f"      - {f}")
            elif cmd == "/deed":
                st = shae.status()
                print(f"    constants: {st['constants']}, system rules: {st['system_rules']}")
                print(f"    floor immutable (C=N!=0); sky = recorder; truth = 4-value")
            elif cmd == "/income":
                r = shae.economic.surface_best(3)
                print(f"    {r.notes}")
            elif cmd == "/companion":
                on = arg != "off"
                r = shae.companion.set_enabled(on)
                print(f"    {r.notes} (mode: {shae.companion.mode.value})")
            else:
                print(f"  unknown command {cmd}. /help for the list.")
            continue

        # Ordinary input -> Shae reasons about it.
        out = shae.respond(line)
        if "error" in out:
            print(f"  [{out['error']}]")
        elif out.get("verdict") == "BLOCKED":
            print(f"  [BLOCKED] {out['reason']}")
        else:
            print(f"shae> {out['response']}")
            print(f"      (verdict={out['verdict']}, domain={out['domain']}, "
                  f"sigma-k={out['confidence_sigma_k']:g}, phase_locked={out['phase_locked']})")


if __name__ == "__main__":
    run()
