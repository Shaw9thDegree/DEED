#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  hardware.py
  DETECT AND CONFORM  —  never hardcode hardware
--------------------------------------------------------------------------------
  Architect rule: Shae seeks the hardware she is on and conforms to it. Nothing
  is hardcoded. Every probe soft-fails to a safe, non-zero default so the system
  runs on anything from a salvaged laptop to the MSI GS66, online or offline,
  with or without third-party libraries installed.

  Produces the `hw` dict that core.boot() and security.boot() consume:
    cpu_arch, cpu_count, ram_gb, platform, storage_devices, gpu, db_path, ...
  Every field is discovered; if discovery fails, a floored default is used and
  the degradation is recorded (never silent, per the security-fallback rule).
================================================================================
"""

from __future__ import annotations

import os
import platform
import shutil
import tempfile
from typing import Dict, List

from deed_primitives import DeedValue, TruthValue, DeedResult, EPSILON


def _probe_cpu_count() -> int:
    try:
        n = os.cpu_count()
        return n if n and n > 0 else 1
    except Exception:
        return 1


def _probe_ram_gb() -> float:
    # Try psutil; fall back to os.sysconf; fall back to a floored default.
    try:
        import psutil  # type: ignore
        return round(psutil.virtual_memory().total / (1024 ** 3), 2)
    except Exception:
        pass
    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        return round((pages * page_size) / (1024 ** 3), 2)
    except Exception:
        return 1.0  # floored default; never 0


def _probe_storage() -> List[Dict]:
    devices: List[Dict] = []
    try:
        import psutil  # type: ignore
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
                devices.append({
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype or "unknown",
                    "total_gb": round(usage.total / (1024 ** 3), 2),
                })
            except Exception:
                continue
    except Exception:
        pass
    if not devices:
        # Fall back to the root/cwd device via shutil.
        try:
            total, _, _ = shutil.disk_usage(os.getcwd())
            devices.append({"mountpoint": os.path.abspath(os.sep),
                            "fstype": "unknown",
                            "total_gb": round(total / (1024 ** 3), 2)})
        except Exception:
            devices.append({"mountpoint": "/", "fstype": "unknown", "total_gb": 1.0})
    return devices


def _probe_gpu() -> Dict:
    """Detect GPU and vendor (NVIDIA/AMD/Apple/none). Conforms; never assumes."""
    gpu = {"present": False, "vendor": "none", "backend": "cpu"}
    # NVIDIA
    if shutil.which("nvidia-smi"):
        gpu.update(present=True, vendor="nvidia", backend="cuda")
        return gpu
    # AMD / ROCm
    if shutil.which("rocminfo") or os.path.exists("/opt/rocm"):
        gpu.update(present=True, vendor="amd", backend="rocm")
        return gpu
    # Apple Silicon
    if platform.system() == "Darwin" and platform.machine() in ("arm64", "aarch64"):
        gpu.update(present=True, vendor="apple", backend="metal")
        return gpu
    # Try torch as a last resort (optional dependency)
    try:
        import torch  # type: ignore
        if torch.cuda.is_available():
            gpu.update(present=True, vendor="nvidia", backend="cuda")
        elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            gpu.update(present=True, vendor="apple", backend="metal")
    except Exception:
        pass
    return gpu


def _resolve_db_path() -> str:
    """A writable directory for Shae's databases. Conforms to the environment;
    prefers a stable home dir, falls back to a temp dir, never fails."""
    candidates = [
        os.path.join(os.path.expanduser("~"), ".shae_v34"),
        os.path.join(os.getcwd(), ".shae_v34"),
        os.path.join(tempfile.gettempdir(), "shae_v34"),
    ]
    for path in candidates:
        try:
            os.makedirs(path, exist_ok=True)
            testfile = os.path.join(path, ".writetest")
            with open(testfile, "w") as f:
                f.write("ok")
            os.remove(testfile)
            return path
        except Exception:
            continue
    # Last resort: a fresh temp dir.
    return tempfile.mkdtemp(prefix="shae_v34_")


def detect() -> Dict:
    """Detect the full hardware profile, conforming to whatever is present.
    Returns the `hw` dict consumed by every module's boot()."""
    degradations: List[str] = []

    cpu_count = _probe_cpu_count()
    ram_gb = _probe_ram_gb()
    if ram_gb <= 0:
        ram_gb = 1.0
        degradations.append("ram probe failed; floored to 1.0 GB")

    storage = _probe_storage()
    gpu = _probe_gpu()
    db_path = _resolve_db_path()

    hw = {
        "cpu_arch": platform.machine() or "unknown",
        "cpu_count": cpu_count,
        "ram_gb": ram_gb,
        "platform": platform.system() or "unknown",
        "platform_release": platform.release() or "unknown",
        "python_version": platform.python_version(),
        "storage_devices": storage,
        "gpu": gpu,
        "db_path": db_path,
        "compute_backend": gpu["backend"],
        "degradations": degradations,
        # Worker count conforms to CPU; floored at 1, capped to keep a laptop sane.
        "recommended_workers": max(1, min(cpu_count, 8)),
    }
    return hw


def profile_report(hw: Dict) -> DeedResult:
    """A truth-bearing summary of the detected profile. TRUE = full detection;
    PROBE = ran with one or more floored/degraded probes (flagged, not silent)."""
    if hw.get("degradations"):
        return DeedResult(
            truth=TruthValue.PROBE,
            notes="hardware detected with degradations: " + "; ".join(hw["degradations"]),
        )
    cores = hw["cpu_count"]
    ram = hw["ram_gb"]
    backend = hw["compute_backend"]
    return DeedResult(
        truth=TruthValue.TRUE,
        value=DeedValue(max(cores, EPSILON)),
        notes=f"hardware conformed: {hw['cpu_arch']} {cores} cores, {ram} GB RAM, "
              f"compute={backend}, {len(hw['storage_devices'])} volume(s)",
    )


# Module-level cache so boot is idempotent.
_hw: Dict = {}


def boot() -> Dict:
    global _hw
    _hw = detect()
    return _hw


def get_hw() -> Dict:
    return _hw if _hw else detect()
