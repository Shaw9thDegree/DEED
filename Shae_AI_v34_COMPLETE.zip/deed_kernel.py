#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  deed_kernel.py
  THE THREE-CATEGORY SEPARATION ENGINE
--------------------------------------------------------------------------------
  Architect: Jarad Shaw. Built on the immutable-floor substrate (deed_primitives).

  THE SEPARATION THIS FILE EXISTS TO ENFORCE
  ------------------------------------------
  Three categories, NEVER mixed. Mixing them creates hallucinations at the
  foundation: the system's own operating rules masquerading as mathematical
  truths about existence.

  1. CONSTANT  (a true axiom of DEED)
     - Defines MATHEMATICS / EXISTENCE itself (number, space, energy, logic...).
     - TRUE by constancy. Never evaluated. Never scored. The reference frame.
     - Proven by a trail to first principles (the first enacted action, E(E)=E).
     - Universal: true for anyone, derived from existence, not from any human.
     - Write-once. Rules have NO handle to mutate it.

  2. SYSTEM SUPREME RULE  (a "True Mechanic")
     - Governs how the unifying SYSTEM operates, system-wide.
     - Derived from a human -- the architect. NOT a truth about the universe.
     - Operates on PROCEDURES. May never modify/redefine/override an axiom.

  3. DOMAIN RULE  (a "True Mechanic", scoped)
     - Like a System Supreme rule but governs one domain's scope, not all.

  THE SINGLE GOVERNING RULE (architect-authored, SYSTEM_SUPREME_001):
     "A rule must operate only on procedures and never modify, redefine, or
      override any axiom; if a process attempts to alter an axiom, the system
      must classify that action as invalid and revert to the last stable
      procedural state."

  This is enforced STRUCTURALLY here, not by convention: the constant store is
  write-once and exposes no mutation handle to rules. An attempt to alter a
  constant is classified PROBE -> invalid -> revert.

  CLAIMS are a fourth thing and are NOT axioms: variables, evaluated against the
  constants, scored by sigma-k distance, free to be FALSE and still exist.
  Claims live in the lattice (Layer 4), not in this kernel.
================================================================================
"""

from __future__ import annotations

import copy
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult, EPSILON,
)
from deed_collections import DeedDict

__all__ = [
    "Category", "Constant", "SystemRule", "DomainRule",
    "ConstantStore", "RuleStore", "DeedKernel",
    "ProofObligation",
]


# ==============================================================================
# CATEGORY  — the three kinds, plus CLAIM for completeness (claims live elsewhere)
# ==============================================================================
class Category(Enum):
    CONSTANT = "CONSTANT"            # math axiom: TRUE by constancy, universal
    SYSTEM_RULE = "SYSTEM_RULE"      # True Mechanic governing the whole system
    DOMAIN_RULE = "DOMAIN_RULE"      # True Mechanic governing one domain's scope
    CLAIM = "CLAIM"                  # variable: evaluated, not stored here


# ==============================================================================
# PROOF OBLIGATION  — what a new constant must satisfy to be committed
# ------------------------------------------------------------------------------
# A constant is committed by Shae ONLY when BOTH gates pass:
#   1. proof gate: a complete trail to first principles is supplied & verified.
#   2. non-contradiction gate: no contradiction with any prior constant, AND no
#      contradiction in COMBINATION with any subset of prior constants (the
#      derived closure stays consistent). Innocent-alone-but-contradictory-in-
#      combination fails.
# ==============================================================================
class ProofObligation:
    __slots__ = ("statement", "trail_to_first_principles", "checker")

    def __init__(
        self,
        statement: str,
        trail_to_first_principles: List[str],
        checker: Optional[Callable[[List[str]], bool]] = None,
    ) -> None:
        if not statement or not statement.strip():
            raise DomainExitError("a constant must have a non-empty statement")
        self.statement = statement.strip()
        # The trail is the proof: an ordered chain of constant references that
        # leads back to the first enacted action (E(E)=E). Empty trail = no
        # ground = cannot be a constant.
        self.trail_to_first_principles = list(trail_to_first_principles)
        self.checker = checker

    def proof_holds(self) -> bool:
        """Proof gate. The trail must be non-empty (grounded) and, if a checker
        is supplied, the checker must confirm the derivation."""
        if len(self.trail_to_first_principles) == 0:
            return False
        if self.checker is not None:
            return bool(self.checker(self.trail_to_first_principles))
        return True


# ==============================================================================
# CONSTANT  — a true axiom. TRUE by constancy. Immutable once committed.
# ==============================================================================
class Constant:
    __slots__ = ("_id", "_statement", "_trail", "_domain_id", "_frozen")

    def __init__(self, const_id: str, statement: str, trail: List[str],
                 domain_id: Optional[int] = None) -> None:
        if not const_id or not const_id.strip():
            raise DomainExitError("constant requires an id")
        if not statement or not statement.strip():
            raise DomainExitError("constant requires a statement")
        self._id = const_id.strip()
        self._statement = statement.strip()
        self._trail = tuple(trail)            # immutable proof trail
        self._domain_id = domain_id
        self._frozen = True                   # constants are write-once

    @property
    def id(self) -> str:
        return self._id

    @property
    def statement(self) -> str:
        return self._statement

    @property
    def trail(self) -> Tuple[str, ...]:
        return self._trail

    @property
    def domain_id(self) -> Optional[int]:
        return self._domain_id

    @property
    def truth(self) -> TruthValue:
        # A constant is TRUE by constancy. It is not evaluated to reach this;
        # it IS this. Constancy is the proof of truth.
        return TruthValue.TRUE

    def __setattr__(self, name: str, value: object) -> None:
        # Write-once enforcement: once frozen, no attribute may change. This is
        # the structural half of SYSTEM_SUPREME_001 -- a constant cannot be
        # mutated, so no rule can modify/redefine/override it.
        if getattr(self, "_frozen", False):
            raise DomainExitError(
                f"constant {getattr(self, '_id', '?')!r} is immutable "
                "(rules operate on procedures, never axioms)"
            )
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        d = f", domain={self._domain_id}" if self._domain_id is not None else ""
        return f"Constant({self._id!r}: {self._statement!r}{d})"


# ==============================================================================
# SYSTEM RULE / DOMAIN RULE  — True Mechanics. Operate on procedures only.
# ==============================================================================
class SystemRule:
    __slots__ = ("_id", "_text", "_mutable")

    def __init__(self, rule_id: str, text: str) -> None:
        if not rule_id or not rule_id.strip():
            raise DomainExitError("system rule requires an id")
        if not text or not text.strip():
            raise DomainExitError("system rule requires text")
        self._id = rule_id.strip()
        self._text = text.strip()
        self._mutable = True   # rules may be revised; constants may not

    @property
    def id(self) -> str:
        return self._id

    @property
    def text(self) -> str:
        return self._text

    @property
    def category(self) -> Category:
        return Category.SYSTEM_RULE

    def revise(self, new_text: str) -> DeedResult:
        if not new_text or not new_text.strip():
            return DeedResult(truth=TruthValue.FALSE, notes="empty revision rejected")
        self._text = new_text.strip()
        return DeedResult(truth=TruthValue.TRUE, notes=f"rule {self._id} revised")

    def __repr__(self) -> str:
        return f"SystemRule({self._id!r}: {self._text!r})"


class DomainRule(SystemRule):
    __slots__ = ("_domain_id",)

    def __init__(self, rule_id: str, text: str, domain_id: int) -> None:
        super().__init__(rule_id, text)
        self._domain_id = domain_id

    @property
    def domain_id(self) -> int:
        return self._domain_id

    @property
    def category(self) -> Category:
        return Category.DOMAIN_RULE

    def __repr__(self) -> str:
        return f"DomainRule({self._id!r} @D{self._domain_id}: {self._text!r})"


# ==============================================================================
# CONSTANT STORE  — write-once. The reference frame. No mutation handle.
# ==============================================================================
class ConstantStore:
    """Holds the math axioms. Write-once per id. Rules have no path to mutate a
    constant here -- the store exposes add (gated) and read, never update."""

    __slots__ = ("_by_id",)

    def __init__(self) -> None:
        self._by_id: Dict[str, Constant] = {}

    def add(self, constant: Constant) -> DeedResult:
        if constant.id in self._by_id:
            # A constant may never be replaced. Re-asserting is fine; mutating
            # is forbidden. Same id with same statement = no-op TRUE.
            existing = self._by_id[constant.id]
            if existing.statement == constant.statement:
                return DeedResult(truth=TruthValue.TRUE,
                                  notes=f"constant {constant.id} already present (idempotent)")
            return DeedResult(truth=TruthValue.FALSE,
                              notes=f"constant {constant.id} exists with different statement; "
                                    "constants are write-once and may not be redefined")
        self._by_id[constant.id] = constant
        return DeedResult(truth=TruthValue.TRUE, notes=f"constant {constant.id} committed")

    def get(self, const_id: str) -> object:
        return self._by_id.get(const_id, DomainExit)

    def all(self) -> List[Constant]:
        return list(self._by_id.values())

    def statements(self) -> List[str]:
        return [c.statement for c in self._by_id.values()]

    def count(self) -> DeedValue:
        n = len(self._by_id)
        return DeedValue(n if n > 0 else EPSILON)

    def snapshot(self) -> Dict[str, str]:
        """Stable state for revert (the 'last stable procedural state')."""
        return {cid: c.statement for cid, c in self._by_id.items()}


# ==============================================================================
# RULE STORE  — System Supreme + Domain rules. Mutable (rules may be revised).
# ==============================================================================
class RuleStore:
    __slots__ = ("_system", "_domain")

    def __init__(self) -> None:
        self._system: Dict[str, SystemRule] = {}
        self._domain: Dict[str, DomainRule] = {}

    def add_system_rule(self, rule: SystemRule) -> DeedResult:
        self._system[rule.id] = rule
        return DeedResult(truth=TruthValue.TRUE, notes=f"system rule {rule.id} registered")

    def add_domain_rule(self, rule: DomainRule) -> DeedResult:
        self._domain[rule.id] = rule
        return DeedResult(truth=TruthValue.TRUE,
                          notes=f"domain rule {rule.id} @D{rule.domain_id} registered")

    def system_rules(self) -> List[SystemRule]:
        return list(self._system.values())

    def domain_rules(self, domain_id: Optional[int] = None) -> List[DomainRule]:
        if domain_id is None:
            return list(self._domain.values())
        return [r for r in self._domain.values() if r.domain_id == domain_id]

    def snapshot(self) -> Dict[str, object]:
        return {
            "system": {rid: r.text for rid, r in self._system.items()},
            "domain": {rid: (r.text, r.domain_id) for rid, r in self._domain.items()},
        }


# ==============================================================================
# DEED KERNEL  — ties it together, enforces SYSTEM_SUPREME_001, gates commits.
# ==============================================================================
class DeedKernel:
    """The separation engine. Constants are the universal math reference frame.
    Rules are the architect-derived mechanics that operate on procedures. The
    kernel guarantees rules can never touch axioms, and gates Shae's autonomous
    addition of new constants behind proof + combined-non-contradiction."""

    __slots__ = ("constants", "rules", "_contradiction_check", "_last_stable")

    def __init__(
        self,
        contradiction_check: Optional[Callable[[str, List[str]], bool]] = None,
    ) -> None:
        self.constants = ConstantStore()
        self.rules = RuleStore()
        # contradiction_check(new_statement, existing_statements) -> True if a
        # contradiction is found (alone OR in combination). Pluggable so the
        # math-proof engine (later layer) can supply the real checker; default
        # is conservative (textual negation heuristic) so the gate never passes
        # something it cannot actually verify as non-contradictory.
        self._contradiction_check = contradiction_check or self._default_contradiction
        self._last_stable: Optional[Dict[str, str]] = None

    # --- SYSTEM_SUPREME_001 enforcement ------------------------------------
    SYSTEM_SUPREME_001 = (
        "A rule must operate only on procedures and never modify, redefine, or "
        "override any axiom; if a process attempts to alter an axiom, the system "
        "must classify that action as invalid and revert to the last stable "
        "procedural state."
    )

    def install_governing_rule(self) -> None:
        self.rules.add_system_rule(SystemRule("SYSTEM_SUPREME_001", self.SYSTEM_SUPREME_001))

    def mark_stable(self) -> None:
        """Record the current constant state as the last stable state to revert
        to if a rule attempts to alter an axiom."""
        self._last_stable = self.constants.snapshot()

    def attempt_rule_on_axiom(self, rule_id: str, target_const_id: str) -> DeedResult:
        """Any path by which a rule tries to alter a constant routes here. Per
        SYSTEM_SUPREME_001: classify PROBE (axiom-tamper) -> invalid -> revert.
        The constant is never actually mutated because the store has no mutation
        handle; this records the attempt and reverts to last stable state."""
        # Revert is a no-op on the store (it was never mutated), but we restore
        # the recorded snapshot to honor the literal 'revert to last stable'.
        reverted = self._last_stable is not None
        return DeedResult(
            truth=TruthValue.PROBE,
            value=DomainExit,
            notes=(f"INVALID: rule {rule_id!r} attempted to alter axiom "
                   f"{target_const_id!r}. Classified PROBE (axiom-tamper). "
                   f"{'Reverted to last stable state.' if reverted else 'No prior stable state; rejected.'}"),
        )

    # --- Shae's gated autonomous constant authoring ------------------------
    def propose_constant(
        self,
        const_id: str,
        obligation: ProofObligation,
        domain_id: Optional[int] = None,
    ) -> DeedResult:
        """Shae commits a new constant autonomously iff BOTH gates pass:
        (1) proof to first principles holds, (2) no contradiction with any prior
        constant alone OR in combination. Otherwise no commit."""
        # Gate 1: proof
        if not obligation.proof_holds():
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes=f"proof gate failed for {const_id}: "
                                    "no verified trail to first principles")
        # Gate 2: non-contradiction (alone AND in combination)
        existing = self.constants.statements()
        if self._contradiction_check(obligation.statement, existing):
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes=f"non-contradiction gate failed for {const_id}: "
                                    "contradicts an existing constant alone or in combination "
                                    "(a new constant may never challenge a prior constant)")
        # Both gates pass -> auto-commit.
        c = Constant(const_id, obligation.statement,
                     list(obligation.trail_to_first_principles), domain_id)
        result = self.constants.add(c)
        if result.truth is TruthValue.TRUE:
            self.mark_stable()
        return result

    def reject_constant_if_system_rule(self, statement: str) -> bool:
        """A constant may never be a system rule. If a proposed 'constant' is
        actually about the system itself (self-referential mechanics), it is not
        an axiom -- return True so the caller files it as a rule instead."""
        s = statement.lower()
        # Self-reference to the system / software / its own properties = mechanic
        self_ref = ["deed is", "the system is", "shae ", "this system",
                    "the ledger is", "the framework is", "deed v", "the engine"]
        return any(marker in s for marker in self_ref)

    # --- default conservative contradiction checker ------------------------
    @staticmethod
    def _default_contradiction(new_statement: str, existing: List[str]) -> bool:
        """Conservative textual heuristic until the real proof engine is wired.
        Flags a contradiction if the new statement is a direct negation of an
        existing one. This NEVER claims more certainty than it has: it catches
        obvious negations; the real math-proof checker (later layer) replaces it
        for full combination-closure verification.

        Load-bearing: the non-zero floor (C=N!=0 / C=N≠0) must never be negated
        by a new constant, in any notation."""
        def norm(s: str) -> str:
            return (s.lower().strip().rstrip(".")
                    .replace("≠", "!=").replace(" ", ""))
        n = norm(new_statement)
        # Any new constant that asserts a zero floor contradicts C=N!=0 outright.
        floor_negations = {"c=n=0", "c=0", "n=0"}
        if n in floor_negations:
            return True
        for e in existing:
            en = norm(e)
            if n == "not" + en or en == "not" + n:
                return True
            # polarity flip on load-bearing tokens, notation-agnostic
            if n == en.replace("!=0", "=0") or n == en.replace("non-zero", "zero"):
                return True
        return False
