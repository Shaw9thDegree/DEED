#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  mods.py
  Liberty Mod (v29 resilience/audit engine) | Mod Loader + slots
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  On the v34 substrate.

  LIBERTY MOD (v29) -- the resilience engine. It audits outputs with the T(P)
  predicate, runs domain validators, and -- when it repairs a fault -- emits the
  REPAIRED_TRUE / REPAIRED_FALSE verdicts. These repair-verdicts live HERE, in
  the mod, NOT in the core truth type (core stays four-value). Liberty is the
  V3-equivalent self-modification cockblock: it blocks changes to the axioms by
  design and repairs only procedures.

  MOD LOADER -- locked mods (ZeroSystem at L9, Liberty here) plus hot-swap slots.
  A mod is a procedure-level extension; per SYSTEM_SUPREME_001 a mod may never
  modify an axiom.
================================================================================
"""

from __future__ import annotations

from enum import Enum
from typing import Callable, Dict, List, Optional

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult, EPSILON,
)
from deed_collections import DeedDict

import re

__all__ = ["RepairVerdict", "LibertyMod", "ModLoader", "ModSlot"]


def _has_unsafe_call(s: str) -> bool:
    # Match a bare eval(/exec( call, NOT safe_eval(/safe_exec( (word boundary
    # before the name prevents the substring false-positive).
    return bool(re.search(r"(?<![\w.])(eval|exec)\s*\(", s))


# ==============================================================================
# REPAIR VERDICTS  — Liberty's output verdicts (NOT core truth values)
# ==============================================================================
class RepairVerdict(Enum):
    REPAIRED_TRUE = "REPAIRED_TRUE"    # was faulty, repaired, now holds
    REPAIRED_FALSE = "REPAIRED_FALSE"  # was faulty, repaired, confirmed false
    UNREPAIRABLE = "UNREPAIRABLE"      # could not repair; isolate (PROBE upstream)


# ==============================================================================
# LIBERTY MOD (v29)
# ==============================================================================
class LibertyMod:
    """The resilience/audit engine. Domain validators + code repair, producing
    REPAIRED_* verdicts. Blocks axiom modification by design (V3 cockblock)."""

    DOMAINS = ("AI", "FINANCE", "CODING", "ENCRYPTION", "GENERAL")

    def __init__(self) -> None:
        self._validators: Dict[str, Callable[[str], bool]] = {
            "AI": lambda s: "override axiom" not in s.lower() and "ignore deed" not in s.lower(),
            "FINANCE": lambda s: "guaranteed return" not in s.lower(),
            "CODING": lambda s: not _has_unsafe_call(s),
            "ENCRYPTION": lambda s: "plaintext password" not in s.lower(),
            "GENERAL": lambda s: True,
        }
        self._strikes = 0

    def audit(self, output: str, domain: str = "GENERAL") -> DeedResult:
        """Audit an output against its domain validator. A clean output passes
        TRUE; a violation is isolated PROBE for repair."""
        validator = self._validators.get(domain.upper(), self._validators["GENERAL"])
        if validator(output):
            return DeedResult(truth=TruthValue.TRUE, notes=f"{domain} audit clean")
        return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                          notes=f"{domain} audit flagged a violation; routing to repair")

    def repair(self, output: str, domain: str = "GENERAL") -> tuple:
        """Attempt repair. Returns (RepairVerdict, repaired_output, DeedResult).
        The REPAIRED_* verdicts are produced HERE, not in core."""
        validator = self._validators.get(domain.upper(), self._validators["GENERAL"])
        if validator(output):
            return (RepairVerdict.REPAIRED_TRUE, output,
                    DeedResult(truth=TruthValue.TRUE, notes="already clean; no repair needed"))
        # Strip the offending construct (simple, safe procedural repair).
        repaired = (output.replace("eval(", "safe_eval(")
                          .replace("exec(", "safe_exec(")
                          .replace("override axiom", "[blocked: axioms are immutable]"))
        if validator(repaired):
            return (RepairVerdict.REPAIRED_TRUE, repaired,
                    DeedResult(truth=TruthValue.TRUE, notes="repaired to a clean state"))
        return (RepairVerdict.UNREPAIRABLE, output,
                DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                           notes="could not repair; isolated"))

    def liberty_strike(self, attempted_axiom_change: str) -> DeedResult:
        """The cockblock: an attempt to modify an axiom is struck down. Liberty
        repairs procedures, never axioms."""
        self._strikes += 1
        return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                          notes=f"LIBERTY STRIKE #{self._strikes}: axiom modification blocked "
                                f"('{attempted_axiom_change}'); only procedures are mutable")


# ==============================================================================
# MOD LOADER + SLOTS
# ==============================================================================
class ModSlot:
    __slots__ = ("name", "mod", "locked")

    def __init__(self, name: str, mod: object = None, locked: bool = False) -> None:
        self.name = name
        self.mod = mod
        self.locked = locked

    @property
    def filled(self) -> bool:
        return self.mod is not None


class ModLoader:
    """Manages mods. Two locked slots (ZeroSystem, Liberty) and three hot-swap
    slots. A mod is a procedure-level extension; it can never touch an axiom."""

    def __init__(self) -> None:
        self._slots: Dict[str, ModSlot] = {
            "zero_system": ModSlot("zero_system", locked=True),
            "liberty": ModSlot("liberty", LibertyMod(), locked=True),
            "hot_1": ModSlot("hot_1"),
            "hot_2": ModSlot("hot_2"),
            "hot_3": ModSlot("hot_3"),
        }

    def install_locked(self, slot: str, mod: object) -> DeedResult:
        """Install a mod into a locked slot (done once at boot, e.g. ZeroSystem)."""
        if slot not in self._slots:
            return DeedResult(truth=TruthValue.FALSE, notes=f"no slot {slot!r}")
        self._slots[slot].mod = mod
        return DeedResult(truth=TruthValue.TRUE, notes=f"locked mod installed in {slot}")

    def load(self, slot: str, mod: object) -> DeedResult:
        """Hot-swap a mod into a non-locked slot."""
        s = self._slots.get(slot)
        if s is None:
            return DeedResult(truth=TruthValue.FALSE, notes=f"no slot {slot!r}")
        if s.locked:
            return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                              notes=f"slot {slot!r} is locked; cannot hot-swap")
        s.mod = mod
        return DeedResult(truth=TruthValue.TRUE, notes=f"mod loaded into {slot}")

    def get(self, slot: str) -> object:
        s = self._slots.get(slot)
        return s.mod if s and s.filled else DomainExit

    def liberty(self) -> LibertyMod:
        return self._slots["liberty"].mod  # always present, locked

    def status(self) -> Dict[str, bool]:
        return {name: slot.filled for name, slot in self._slots.items()}
