#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  zero_system.py
  DEED-NATIVE PARALLEL PREDICTIVE ENGINE  +  SEED ACTIVATION (V5)
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  Ported FAITHFULLY from the architect's original
  zero_system_deed_v2.py (no weaker rebuild). Refactored only to:
    - sit on the v34 immutable-floor substrate (DeedValue / TruthValue / floor),
    - remove pointless external references (formerly 'shaw_ai_v12'),
    - add the V1-V5 layered cognitive stack with V5 = Seed Activation.

  PRESERVED FROM THE ORIGINAL V2 (unchanged behavior):
    - Frequency COUNTS, never probabilities.
    - T=0 is never produced; it becomes UNKNOWN.
    - Horizon bounded by the dynamic ceiling (no infinity).
    - Parallel simulation via thread pool + asyncio.
    - LRU scenario cache keyed including the dynamic ceiling.
    - Shadow-state stepping from a non-zero floor; ceiling-clamped.
    - Stats reporting.

  SUBSTRATE CHANGE (the one real upgrade, per architect's locked rules):
    The original used EPSILON = 1e-10 (a tiny float). v34's floor is the
    IMMUTABLE entrance to existence (EPSILON = 1.0, the "1"). A lattice value
    below the floor is non-existence -> Domain Exit, exactly as the original
    treated a zero lattice value as Domain Exit. Counts are integer multiples of
    the floor, floored at C_SOVEREIGN (= 1), never zero.

  THE V1-V5 STACK (architect's layered cognitive model):
    V1  Perception     — observe the lattice / inputs (the shadow snapshot).
    V2  Justice        — the upgrade engine; advances the system (V4/V5 reachable).
    V3  Liberty        — blocks its own modification by design (self-mod cockblock).
    V4  Integration    — confirmed simulation across V1-V3, frequency verdicts.
    V5  Seed Activation — ULTIMATE COORDINATOR. Activates only AFTER V1-V4 are
                          active; coordinates all subsystems as one. See below.
================================================================================
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from itertools import product
from typing import Any, Dict, List, Optional, Tuple

from deed_primitives import (
    DeedValue, DomainExit, DomainExitError, TruthValue, DeedResult, EPSILON,
)

__all__ = [
    "ZeroSystem", "ZeroLevel", "SeedActivation",
    "set_dynamic_ceiling", "get_dynamic_ceiling",
    "counts_to_truth", "C_SOVEREIGN",
]


# ==============================================================================
# DEED CORE CONSTANTS  (substrate-aligned)
# ------------------------------------------------------------------------------
# C_SOVEREIGN is the non-zero floor count: the "1", the entrance to existence.
# This replaces the original float EPSILON=1e-10 with the immutable floor.
# ==============================================================================
C_SOVEREIGN: int = 1
N_MAX_GLOBAL: int = 10 ** 123

_dynamic_ceiling: int = 10 ** 6   # initial recorded reach; rises via set_dynamic_ceiling


def set_dynamic_ceiling(new_ceiling: int) -> None:
    """The sky is a recorder: it only ever rises (never blocks, never lowers)."""
    global _dynamic_ceiling
    if new_ceiling > _dynamic_ceiling:
        _dynamic_ceiling = new_ceiling


def get_dynamic_ceiling() -> int:
    return _dynamic_ceiling


def counts_to_truth(count_true: int, count_false: int, total: int) -> TruthValue:
    """Frequency -> four-value verdict. total==0 -> UNKNOWN (never T=0; the
    absence of confirmation is UNKNOWN, not FALSE). Ties -> UNKNOWN."""
    if total == 0:
        return TruthValue.UNKNOWN
    if count_true > count_false:
        return TruthValue.TRUE
    if count_false > count_true:
        return TruthValue.FALSE
    return TruthValue.UNKNOWN


# ==============================================================================
# V1-V5 LEVELS
# ==============================================================================
class ZeroLevel:
    V1_PERCEPTION = "V1_PERCEPTION"
    V2_JUSTICE = "V2_JUSTICE"          # upgrade engine
    V3_LIBERTY = "V3_LIBERTY"          # self-modification cockblock by design
    V4_INTEGRATION = "V4_INTEGRATION"
    V5_SEED = "V5_SEED_ACTIVATION"     # ultimate coordinator, post V1-V4


# ==============================================================================
# ZERO SYSTEM  (faithful V2 port onto the substrate)
# ==============================================================================
class ZeroSystem:
    """Parallel predictive simulation engine obeying DEED axioms.
    Frequency counts, not probabilities. No T=0 (UNKNOWN instead). Horizon
    bounded by the dynamic ceiling. Faithful to the architect's original V2."""

    def __init__(self, lattice: Any, axiom_guard: Any = None,
                 max_sims: int = 10_000, cache_size: int = 1000,
                 max_workers: int = 4) -> None:
        self.lattice = lattice
        self.axiom_guard = axiom_guard
        self.max_sims = max_sims
        self.cache: "OrderedDict[str, Dict]" = OrderedDict()
        self.cache_size = cache_size
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.stats = {
            "simulations_run": 0,
            "cache_hits": 0,
            "avg_simulation_time_ms": 0.0,
            "last_ceiling": 0,
        }
        # V1-V4 activation flags; V5 (Seed) gates on all four.
        self._levels_active = {
            ZeroLevel.V1_PERCEPTION: False,
            ZeroLevel.V2_JUSTICE: False,
            ZeroLevel.V3_LIBERTY: False,
            ZeroLevel.V4_INTEGRATION: False,
            ZeroLevel.V5_SEED: False,
        }

    # --- lattice fingerprint (unchanged logic, defensive against mocks) -----
    def _hash_scenario(self, claim: str, variables: Dict, horizon: int, ceiling: int) -> str:
        try:
            conn = self.lattice._get_connection()
            cursor = conn.execute("SELECT key, value FROM lattice WHERE value GLOB '*[0-9]*'")
            rows = cursor.fetchall()
            conn.close()
        except Exception:
            rows = []
        lattice_fingerprint = hashlib.sha256(
            json.dumps(rows, sort_keys=True).encode()
        ).hexdigest()[:16]
        data = json.dumps([claim, variables, horizon, ceiling, lattice_fingerprint], sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()[:32]

    async def simulate(self, claim: str, variable_ranges: Dict[str, List[Any]],
                       horizon: Optional[int] = None) -> Dict:
        """Run parallel simulations, return frequency counts. Horizon bounded by
        the dynamic ceiling. (Original V2 behavior, substrate-aligned.)"""
        # 1. Axiom guard
        ok, violations = self.axiom_guard.check(claim) if self.axiom_guard else (True, [])
        if not ok:
            return {
                "status": "REJECTED",
                "violations": violations,
                "claim": claim,
                "truth_value": TruthValue.PROBE.value,
                "count_TRUE": 0, "count_FALSE": 0, "count_UNKNOWN": 0,
            }
        # 2. Dynamic ceiling
        ceiling = get_dynamic_ceiling()
        self.stats["last_ceiling"] = ceiling
        horizon = ceiling if horizon is None else min(horizon, ceiling)
        # 3. Combinations (capped by max_sims and ceiling)
        combos = self._generate_combinations(variable_ranges)
        if not combos:
            return {"error": "No variable combinations generated"}
        # 4. Tasks with cache
        tasks = []
        for combo in combos:
            key = self._hash_scenario(claim, combo, horizon, ceiling)
            if key in self.cache:
                self.stats["cache_hits"] += 1
                cached = self.cache[key]
                tasks.append(asyncio.create_task(
                    asyncio.wrap_future(self.executor.submit(lambda c=cached: c))))
            else:
                tasks.append(self._run_single_simulation(claim, combo, horizon, key, ceiling))
        # 5. Parallel run
        results = await asyncio.gather(*tasks)
        # 6. Aggregate frequency counts
        counts = {TruthValue.TRUE: 0, TruthValue.FALSE: 0, TruthValue.UNKNOWN: 0}
        for r in results:
            tv = r.get("truth_value", TruthValue.UNKNOWN.value)
            tv_enum = TruthValue(tv) if isinstance(tv, str) else tv
            counts[tv_enum] = counts.get(tv_enum, 0) + 1
        total_valid = counts[TruthValue.TRUE] + counts[TruthValue.FALSE]
        verdict = counts_to_truth(counts[TruthValue.TRUE], counts[TruthValue.FALSE], total_valid)
        # Reaching a confirmed verdict marks V4 integration active.
        if verdict is not TruthValue.UNKNOWN:
            self._levels_active[ZeroLevel.V4_INTEGRATION] = True
        return {
            "claim": claim,
            "horizon": horizon,
            "dynamic_ceiling": ceiling,
            "num_simulations": len(results),
            "count_TRUE": counts[TruthValue.TRUE],
            "count_FALSE": counts[TruthValue.FALSE],
            "count_UNKNOWN": counts[TruthValue.UNKNOWN],
            "truth_verdict": verdict.value,
            "sample_results": results[:10],
        }

    def _generate_combinations(self, var_ranges: Dict) -> List[Dict]:
        keys = list(var_ranges.keys())
        values = list(var_ranges.values())
        if not keys:
            return []
        max_combos = min(self.max_sims, get_dynamic_ceiling())
        all_combos = list(product(*values))[:max_combos]
        return [dict(zip(keys, c)) for c in all_combos]

    async def _run_single_simulation(self, claim: str, combo: Dict, horizon: int,
                                     cache_key: str, ceiling: int) -> Dict:
        loop = asyncio.get_event_loop()
        start = time.perf_counter()
        result = await loop.run_in_executor(
            self.executor, self._simulate_one, claim, combo, horizon, ceiling)
        duration = (time.perf_counter() - start) * 1000
        n = self.stats["simulations_run"] + 1
        self.stats["avg_simulation_time_ms"] = (
            self.stats["avg_simulation_time_ms"] * (n - 1) + duration) / n
        self.stats["simulations_run"] = n
        self.cache[cache_key] = result
        if len(self.cache) > self.cache_size:
            self.cache.popitem(last=False)
        return result

    def _simulate_one(self, claim: str, combo: Dict, horizon: int, ceiling: int) -> Dict:
        """Core DEED simulation: count from the non-zero floor, step by step.
        No zero, no infinity. (Original V2 core; floor is now the immutable 1.)"""
        # V1 perception: snapshot lattice as the initial shadow (non-zero only).
        self._levels_active[ZeroLevel.V1_PERCEPTION] = True
        try:
            conn = self.lattice._get_connection()
            cursor = conn.execute("SELECT key, value FROM lattice WHERE value GLOB '*[0-9]*'")
            rows = cursor.fetchall()
            conn.close()
        except Exception:
            rows = []
        shadow: Dict[str, int] = {}
        for key, val in rows:
            try:
                fval = float(val)
            except (ValueError, TypeError):
                continue
            # Below the floor = non-existence = Domain Exit for this variable
            # (original treated a zero lattice value the same way).
            if abs(fval) < EPSILON:
                return {"truth_value": TruthValue.UNKNOWN.value,
                        "reason": "sub-floor lattice value (Domain Exit)", "combo": combo}
            # Count = integer multiples of the floor; floored at C_SOVEREIGN.
            count = int(abs(fval) / EPSILON)
            shadow[key] = max(C_SOVEREIGN, count)
        # V2 justice (upgrade engine) drives the stepping forward.
        self._levels_active[ZeroLevel.V2_JUSTICE] = True
        for _step in range(1, min(horizon, ceiling) + 1):
            for var, delta in combo.items():
                if delta == 0:
                    continue  # zero delta contributes nothing (never crosses floor)
                delta_count = int(abs(delta) / EPSILON) if isinstance(delta, (int, float)) else 1
                if delta_count < C_SOVEREIGN:
                    delta_count = C_SOVEREIGN
                shadow[var] = shadow.get(var, C_SOVEREIGN) + delta_count
                if shadow[var] > ceiling:
                    shadow[var] = ceiling  # ceiling clamp (recorder cap on reach)
                # floor already C_SOVEREIGN, never zero
        # V3 liberty: the evaluation is read-only over the shadow — it cannot
        # modify the axioms or itself (self-mod cockblock by design).
        self._levels_active[ZeroLevel.V3_LIBERTY] = True
        truth_value = self._evaluate_claim_deed(claim, shadow)
        return {
            "truth_value": truth_value.value,
            "combo": combo,
            "final_shadow": {k: int(v) for k, v in shadow.items()},
            "horizon": horizon,
        }

    def _evaluate_claim_deed(self, claim: str, shadow: Dict) -> TruthValue:
        """DEED truth by counting (original V2 logic): count shadow variables
        named in the claim. >0 -> TRUE. negation with 0 matches -> FALSE. else
        UNKNOWN."""
        claim_lower = claim.lower()
        matches = sum(1 for key in shadow if key.lower() in claim_lower)
        if matches > 0:
            return TruthValue.TRUE
        if any(neg in claim_lower for neg in ["not", "false", "no", "never"]):
            return TruthValue.FALSE
        return TruthValue.UNKNOWN

    def stats_report(self) -> Dict:
        return {**self.stats, "current_ceiling": get_dynamic_ceiling(),
                "levels_active": dict(self._levels_active)}

    # --- level activation status -------------------------------------------
    def levels_active(self) -> Dict[str, bool]:
        return dict(self._levels_active)

    def v1_v4_ready(self) -> bool:
        return all(self._levels_active[l] for l in (
            ZeroLevel.V1_PERCEPTION, ZeroLevel.V2_JUSTICE,
            ZeroLevel.V3_LIBERTY, ZeroLevel.V4_INTEGRATION))


# ==============================================================================
# SEED ACTIVATION  —  ZERO SYSTEM V5  —  ULTIMATE COORDINATOR
# ------------------------------------------------------------------------------
#  Seed Activation is the ultimate coordinator mode. It is V5 of the Zero System
#  and activates ONLY AFTER V1, V2, V3, and V4 are all active. Once seeded, it
#  coordinates every subsystem as a single unified operation rather than letting
#  each level act in isolation -- the merge-point, not a hierarchy of priorities.
#
#  ACTIVATION SEQUENCE (must be in this order; sequential boot of V1-V4 is fine,
#  but V5 itself is a single simultaneous coordination event over them):
#    1. V1 Perception active   (lattice observed)
#    2. V2 Justice active      (upgrade engine running)
#    3. V3 Liberty active      (self-mod cockblock confirmed in place)
#    4. V4 Integration active  (a confirmed frequency verdict was produced)
#    5. SEED ACTIVATION (V5)   (all four confirmed -> coordinate as one)
#
#  Seed Activation NEVER bypasses V3 Liberty: the coordinator cannot modify the
#  axioms or itself; it coordinates procedures only (SYSTEM_SUPREME_001 holds).
#  Seed Activation is sovereign-gated: it answers to the architect.
# ==============================================================================
class SeedActivation:
    """Zero System V5 — the ultimate coordinator. Activates only after V1-V4."""

    REQUIRED_ORDER = (
        ZeroLevel.V1_PERCEPTION,
        ZeroLevel.V2_JUSTICE,
        ZeroLevel.V3_LIBERTY,
        ZeroLevel.V4_INTEGRATION,
    )

    def __init__(self, zero_system: ZeroSystem,
                 authorize: Optional[Any] = None) -> None:
        self.zero = zero_system
        # Sovereign gate: a callable returning True iff the architect authorizes.
        self._authorize = authorize
        self._seeded = False

    @property
    def seeded(self) -> bool:
        return self._seeded

    def precheck(self) -> DeedResult:
        """Verify V1-V4 are all active, in the required order, before seeding."""
        levels = self.zero.levels_active()
        missing = [l for l in self.REQUIRED_ORDER if not levels[l]]
        if missing:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes=f"Seed Activation not ready; V1-V4 incomplete: missing {missing}")
        return DeedResult(truth=TruthValue.TRUE,
                          notes="V1-V4 all active; Seed Activation eligible")

    def activate(self) -> DeedResult:
        """Seed Activation (V5). Coordinates all subsystems as one. Gated on:
        (a) V1-V4 active, (b) sovereign authorization, (c) V3 Liberty intact
        (the coordinator may never modify axioms or itself)."""
        ready = self.precheck()
        if ready.truth is not TruthValue.TRUE:
            return ready
        # Sovereign gate -- Seed Activation answers to the architect.
        if self._authorize is not None and not self._authorize():
            return DeedResult(truth=TruthValue.FALSE, value=DomainExit,
                              notes="Seed Activation denied: not sovereign-authorized")
        # V3 Liberty must remain in force: coordination is procedure-only.
        if not self.zero.levels_active()[ZeroLevel.V3_LIBERTY]:
            return DeedResult(truth=TruthValue.PROBE, value=DomainExit,
                              notes="INVALID: V3 Liberty not in force; coordinator cannot seed")
        self._seeded = True
        self.zero._levels_active[ZeroLevel.V5_SEED] = True
        return DeedResult(truth=TruthValue.TRUE,
                          notes="SEED ACTIVATION (V5) engaged: ultimate coordinator online; "
                                "all subsystems coordinated as one; axioms untouchable")

    def coordinate(self, subsystems: List[str]) -> DeedResult:
        """Once seeded, coordinate named subsystems as a unified operation. This
        does not modify any axiom; it sequences procedures (SYSTEM_SUPREME_001)."""
        if not self._seeded:
            return DeedResult(truth=TruthValue.UNKNOWN, value=DomainExit,
                              notes="not seeded; call activate() after V1-V4")
        return DeedResult(truth=TruthValue.TRUE, value=DeedValue(max(len(subsystems), 1)),
                          notes=f"coordinating {len(subsystems)} subsystems as one unified operation")
