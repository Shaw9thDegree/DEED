#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  SHAE AI v34.0  —  shae_engine.py
  THE ENGINE — dependency-ordered boot, unified pipeline
--------------------------------------------------------------------------------
  Architect: Jarad Shaw.  Native to the DEED substrate (not a checker bolted on).

  Boots every module in dependency order, wires them together, and exposes the
  respond() pipeline: input -> security -> core truth -> lattice -> persona ->
  Liberty audit -> output. Fully offline. Sovereignty under the architect.
================================================================================
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from deed_primitives import DeedValue, DomainExit, TruthValue, DeedResult, EPSILON
from deed_kernel import DeedKernel, Constant
import hardware
import security as SEC
import core as CORE
from knowledge_tiers import (
    CommonBase, ProfessionalKnowledge, SovereignCore, KnowledgePipe, CommunicationFloor,
)
from shaersal_lattice import ShaersalLattice
from zero_system import ZeroSystem, SeedActivation
from repair_kernel import RepairKernel
from persona import PersonaCore, Companion
from capabilities import CodingRnD, EconomicEngine
from mods import ModLoader

VERSION = "v34.0"
CODENAME = "DEED-Native"


class ShaeEngine:
    """The unified Shae system. Boots in dependency order; sovereignty stays
    under the architect throughout."""

    def __init__(self, architect: str = "Jarad Shaw") -> None:
        self.architect = architect
        self.booted = False
        self.boot_order: List[str] = []
        self._sovereign_authorized = False  # architect must authorize sovereign acts

    # --- sovereign gate ----------------------------------------------------
    def sovereign_authorize(self, on: bool = True) -> None:
        self._sovereign_authorized = on

    def _authorize(self) -> bool:
        return self._sovereign_authorized

    # --- boot (dependency order) -------------------------------------------
    def boot(self) -> DeedResult:
        order: List[str] = []

        # 1. hardware (everything else needs hw)
        self.hw = hardware.boot()
        order.append("hardware")

        # 2. kernel (the constant/rule frame)
        self.kernel = DeedKernel()
        self.kernel.install_governing_rule()
        order.append("kernel")

        # 3. security (rides hw)
        self.security_boot = SEC.boot(self.hw)
        order.append("security")

        # 4. core (rides hw + kernel)
        self.core = CORE.boot(self.hw, kernel=self.kernel)
        order.append("core")

        # 5. knowledge tiers (sovereign core reads the kernel)
        self.common = CommonBase()
        self.professional = ProfessionalKnowledge(kernel=self.kernel)
        self.sovereign = SovereignCore(self.kernel, architect=self.architect)
        self.knowledge = KnowledgePipe(self.common, self.professional, self.sovereign)
        self.comm_floor = CommunicationFloor()
        order.append("knowledge_tiers")

        # 6. lattice (the mind) — simultaneous emergence
        self.lattice = ShaersalLattice()
        emergence = self.lattice.emerge()
        order.append("shaersal_lattice")

        # 7. zero system + seed activation (rides lattice/core)
        self.zero = ZeroSystem(lattice=_LatticeShim(), axiom_guard=_AxiomGuardShim(self.security_boot))
        self.seed = SeedActivation(self.zero, authorize=self._authorize)
        order.append("zero_system")

        # 8. repair kernel
        self.repair = RepairKernel()
        order.append("repair_kernel")

        # 9. persona + companion
        self.persona = PersonaCore(name="Shae")
        self.companion = Companion(enabled=True)  # KEPT per architect
        order.append("persona")

        # 10. capabilities
        self.coding = CodingRnD()
        self.economic = EconomicEngine()
        order.append("capabilities")

        # 11. mods (locked: zero_system, liberty)
        self.mods = ModLoader()
        self.mods.install_locked("zero_system", self.zero)
        self.liberty = self.mods.liberty()
        order.append("mods")

        self.boot_order = order
        self.booted = True
        return DeedResult(
            truth=TruthValue.TRUE if emergence.truth is TruthValue.TRUE else TruthValue.PROBE,
            value=DeedValue(len(order)),
            notes=f"Shae {VERSION} ({CODENAME}) booted: {len(order)} subsystems in order; "
                  f"emergence={emergence.truth.value}; security={self.security_boot.truth.value}",
        )

    # --- the response pipeline ---------------------------------------------
    def respond(self, user_input: str) -> Dict[str, object]:
        """input -> security -> core truth -> lattice -> persona -> Liberty audit.
        Returns a structured result; never crashes (faults isolate)."""
        if not self.booted:
            return {"error": "engine not booted"}

        # 1. security gate
        sec = SEC.check_input(user_input)
        if sec.truth is TruthValue.FALSE:
            return {"verdict": "BLOCKED", "reason": sec.notes}

        # 2. core truth evaluation
        result = self.core.evaluate(user_input)

        # 3. lattice: perceive + (if phase-locked) act
        self.lattice.confirm_phase_lock(rising_input=max(result.confidence.value, EPSILON))
        act = self.lattice.perceive_and_act(
            stimulus=max(result.confidence.value, EPSILON),
            expectation=max(self.lattice.akashic.reflected_signal().value, EPSILON),
            decision="respond")

        # 4. persona shaping (never alters the verdict)
        shaped = self.persona.shape(result.truth_value,
                                    f"[{result.domain_name}] {result.notes}")

        # 5. Liberty audit of the outgoing text
        audit = self.liberty.audit(shaped, domain="AI")
        if audit.truth is TruthValue.PROBE:
            verdict, repaired, _ = self.liberty.repair(shaped, domain="AI")
            shaped = repaired

        return {
            "verdict": result.truth_value.value,
            "domain": result.domain_name,
            "confidence_sigma_k": result.confidence.value,
            "phase_locked": self.lattice.phase_locked,
            "agency": act.notes,
            "response": shaped,
        }

    # --- introspection -----------------------------------------------------
    def status(self) -> Dict[str, object]:
        if not self.booted:
            return {"booted": False}
        return {
            "version": VERSION, "codename": CODENAME, "architect": self.architect,
            "booted": True, "boot_order": self.boot_order,
            "constants": int(self.kernel.constants.count().value),
            "system_rules": len(self.kernel.rules.system_rules()),
            "hardware": f"{self.hw['cpu_arch']} {self.hw['cpu_count']}c {self.hw['ram_gb']}GB {self.hw['compute_backend']}",
            "emerged": self.lattice.emerged,
            "phase_locked": self.lattice.phase_locked,
            "personal_floor": self.lattice.akashic.personal_floor.value,
            "comm_floor": self.comm_floor.level.value,
            "companion_mode": self.companion.mode.value,
            "mods": self.mods.status(),
            "sovereign_authorized": self._sovereign_authorized,
        }


# --- light shims so ZeroSystem can run without an external lattice DB --------
class _LatticeShim:
    """Minimal lattice interface for ZeroSystem when running standalone/offline."""
    def __init__(self) -> None:
        self._data = {"floor": 1.0, "reach": 100.0}
    def _get_connection(self):
        return self
    def execute(self, sql, params=()):
        return _CursorShim(self._data)
    def close(self):
        pass

class _CursorShim:
    def __init__(self, data):
        self.rows = [(k, str(v)) for k, v in data.items()]
    def fetchall(self):
        return self.rows
    def fetchone(self):
        return self.rows[0] if self.rows else None

class _AxiomGuardShim:
    """Bridges ZeroSystem's axiom-guard check to the security breach detector."""
    def __init__(self, security_boot_result):
        pass
    def check(self, claim):
        sec = SEC.check_input(claim)
        if sec.truth is TruthValue.FALSE:
            return False, [sec.notes]
        return True, []
