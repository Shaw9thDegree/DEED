#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tests for knowledge_tiers.py — three-tier architecture."""

from deed_primitives import TruthValue, DomainExitError, is_exit, DeedValue
from deed_kernel import DeedKernel, Constant
from knowledge_tiers import (
    Tier, KnowledgeEntry, CommonBase, ProfessionalKnowledge,
    SovereignCore, KnowledgePipe, CommunicationFloor,
)

passed = 0; failed = []
def ck(name, cond):
    global passed
    if cond: passed += 1; print(f"  PASS  {name}")
    else: failed.append(name); print(f"  FAIL  {name}")
def raises_exit(fn):
    try: fn(); return False
    except DomainExitError: return True

print("=" * 70)
print("  KNOWLEDGE TIERS TEST — common / professional / sovereign")
print("=" * 70)

# --- Tier 1: common base always active, 4yr-grad competencies ---
cb = CommonBase()
ck("common base has language competency", cb.has_competency("language_and_grammar"))
ck("common base has communication competency", cb.has_competency("communication_and_register"))
ck("common base has common-sense competency", cb.has_competency("common_sense_reasoning"))
ck("common base has platform operation", cb.has_competency("platform_operation"))
ck("common base has 4yr-grad academic breadth", cb.has_competency("general_academic_4yr"))
ck("common entry rejects empty content", raises_exit(lambda: KnowledgeEntry("k", "", Tier.COMMON)))

# --- Tier 2: professional dormant until task, pipe-link, sleep ---
pk = ProfessionalKnowledge()
pk.register(KnowledgeEntry("nephrology_dosing", "deep renal dosing tables", Tier.PROFESSIONAL, domain_id=15))
ck("professional domain starts dormant", pk.is_dormant(15))
ck("dormant domain not in active context", len(pk.active(15)) == 0)
woke = pk.wake(15)
ck("waking a domain pipe-links it", woke.truth is TruthValue.TRUE)
ck("woken domain now in active context", len(pk.active(15)) == 1)
ck("waking a domain with no knowledge = UNKNOWN", pk.wake(99).truth is TruthValue.UNKNOWN)
pk.sleep(15)
ck("sleep returns domain to dormancy", pk.is_dormant(15))

# --- professional upgrade gating (Shae learns) ---
up_ok = pk.upgrade(KnowledgeEntry("new_technique", "confirmed renal technique X", Tier.PROFESSIONAL, domain_id=15), ["confirmed_trial"])
ck("upgrade with trail succeeds", up_ok.truth is TruthValue.TRUE)
up_bad = pk.upgrade(KnowledgeEntry("ungrounded", "claim", Tier.PROFESSIONAL, domain_id=15), [])
ck("upgrade without trail rejected", up_bad.truth is TruthValue.FALSE)

# --- Tier 3: sovereign core grounds claims against the constant frame ---
k = DeedKernel(); k.install_governing_rule()
k.constants.add(Constant("C0001", "every quantity is an integer multiple of epsilon", ["E(E)=E"]))
sc = SovereignCore(k, architect="Jarad Shaw")
ck("sovereignty stays under the architect", sc.architect == "Jarad Shaw")
ck("claim trailing to a constant is grounded",
   sc.ground_of(["C0001", "some_step"]).truth is TruthValue.TRUE)
ck("claim trailing to E(E)=E root is grounded",
   sc.ground_of(["E(E)=E"]).truth is TruthValue.TRUE)
ck("ungrounded claim (empty trail) fails", sc.ground_of([]).truth is TruthValue.FALSE)
ck("claim not reaching the frame = UNKNOWN", sc.ground_of(["random_step"]).truth is TruthValue.UNKNOWN)

# --- Knowledge pipe: common always on, deep only during task ---
pipe = KnowledgePipe(cb, pk, sc)
ctx_idle = pipe.active_context()
ck("idle context: common active, professional dormant",
   ctx_idle["common_base"].startswith("active") and ctx_idle.get("professional") == "dormant")
pipe.begin_task("task1", 15)
ctx_task = pipe.active_context("task1")
ck("during task: professional domain linked", ctx_task.get("professional_domain") == 15)
ck("sovereign core always present", "sovereign_core" in ctx_task)
pipe.end_task("task1")
ck("after task: domain dormant again", pk.is_dormant(15))

# --- Communication floor rises toward architect parity ---
cf = CommunicationFloor()
ck("comm floor starts at 4yr-grad level", cf.level.value == 72.0)
ck("comm floor not at parity initially", not cf.at_parity)
cf.confirm_experience("clear technical explanation confirmed", 20)
ck("confirmed experience raises comm floor", cf.level.value == 92.0)
r = cf.confirm_experience("nuanced register match confirmed", 10)
ck("comm floor reaches architect parity at 100+", cf.at_parity)
ck("comm floor only rises (negative gain rejected)",
   cf.confirm_experience("regression", -5).truth is TruthValue.FALSE)

print("=" * 70)
total = passed + len(failed)
print(f"  {passed}/{total} passed")
if failed:
    for f_ in failed: print(f"    FAILED: {f_}")
else:
    print("  KNOWLEDGE TIERS SOUND")
print("=" * 70)
import sys
sys.exit(0 if not failed else 1)
