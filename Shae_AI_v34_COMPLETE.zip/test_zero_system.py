#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tests for zero_system.py — faithful V2 port + Seed Activation (V5)."""

import asyncio
from deed_primitives import TruthValue
from zero_system import (
    ZeroSystem, ZeroLevel, SeedActivation,
    set_dynamic_ceiling, get_dynamic_ceiling, counts_to_truth, C_SOVEREIGN,
)

passed = 0; failed = []
def ck(name, cond):
    global passed
    if cond: passed += 1; print(f"  PASS  {name}")
    else: failed.append(name); print(f"  FAIL  {name}")


class MockLattice:
    def __init__(self):
        self.data = {"position": 5.0, "velocity": 2.0, "mass": 10.0, "temperature": 300.0}
    def _get_connection(self): return self
    def execute(self, sql, params=()): return MockCursor(self.data)
    def close(self): pass

class MockCursor:
    def __init__(self, data):
        self.rows = [(k, str(v)) for k, v in data.items()]; self.idx = 0
    def fetchall(self): return self.rows
    def fetchone(self):
        if self.idx < len(self.rows):
            r = self.rows[self.idx]; self.idx += 1; return r
        return None

class MockAxiomGuard:
    @staticmethod
    def check(claim): return True, []


print("=" * 70)
print("  ZERO SYSTEM TEST — V2 port + Seed Activation (V5)")
print("=" * 70)

# --- counts_to_truth: frequency, never T=0 ---
ck("total 0 -> UNKNOWN (never T=0)", counts_to_truth(0, 0, 0) is TruthValue.UNKNOWN)
ck("more true -> TRUE", counts_to_truth(5, 2, 7) is TruthValue.TRUE)
ck("more false -> FALSE", counts_to_truth(1, 6, 7) is TruthValue.FALSE)
ck("tie -> UNKNOWN", counts_to_truth(3, 3, 6) is TruthValue.UNKNOWN)

# --- dynamic ceiling is a recorder: only rises ---
start = get_dynamic_ceiling()
set_dynamic_ceiling(start - 100)
ck("ceiling does not lower", get_dynamic_ceiling() == start)
set_dynamic_ceiling(start + 1000)
ck("ceiling rises", get_dynamic_ceiling() == start + 1000)

# --- C_SOVEREIGN is the floor count (the '1') ---
ck("C_SOVEREIGN is the non-zero floor (1)", C_SOVEREIGN == 1)

# --- simulate: frequency counts, ceiling-bounded horizon ---
async def run_sim():
    z = ZeroSystem(MockLattice(), MockAxiomGuard(), max_sims=200)
    res = await z.simulate("the position will move forward",
                           {"position": [0.1, 0.5, 1.0], "velocity": [0.2, 0.5]},
                           horizon=50)
    return z, res

z, res = asyncio.run(run_sim())
ck("simulate returns frequency counts (not probabilities)",
   all(k in res for k in ("count_TRUE", "count_FALSE", "count_UNKNOWN")))
ck("simulate has no probability field", "prob_truth" not in res and "mean_T" not in res)
ck("horizon bounded by ceiling", res["horizon"] <= get_dynamic_ceiling())
ck("verdict is a four-value truth string",
   res["truth_verdict"] in ("TRUE", "FALSE", "UNKNOWN", "PROBE"))
ck("claim naming a lattice var trends TRUE", res["count_TRUE"] > 0)

# --- V1-V4 activate through simulation ---
levels = z.levels_active()
ck("V1 perception active after sim", levels[ZeroLevel.V1_PERCEPTION])
ck("V2 justice active after sim", levels[ZeroLevel.V2_JUSTICE])
ck("V3 liberty active after sim", levels[ZeroLevel.V3_LIBERTY])
ck("V4 integration active after confirmed verdict", levels[ZeroLevel.V4_INTEGRATION] or res["truth_verdict"] == "UNKNOWN")

# Force a clean V1-V4 ready state for seed tests
z._levels_active[ZeroLevel.V4_INTEGRATION] = True
ck("v1_v4_ready true once all four active", z.v1_v4_ready())

# --- Seed Activation (V5): requires V1-V4, sovereign auth, V3 intact ---
# Not ready case
z2 = ZeroSystem(MockLattice(), MockAxiomGuard())
seed2 = SeedActivation(z2)
ck("seed precheck UNKNOWN before V1-V4", seed2.precheck().truth is TruthValue.UNKNOWN)
ck("seed activate blocked before V1-V4", seed2.activate().truth is TruthValue.UNKNOWN)

# Ready + authorized
seed = SeedActivation(z, authorize=lambda: True)
ck("seed precheck TRUE after V1-V4", seed.precheck().truth is TruthValue.TRUE)
act = seed.activate()
ck("SEED ACTIVATION engages after V1-V4 + auth", act.truth is TruthValue.TRUE)
ck("seeded flag set", seed.seeded)
ck("V5 marked active on the zero system", z.levels_active()[ZeroLevel.V5_SEED])
ck("coordinator coordinates subsystems as one",
   seed.coordinate(["lattice", "liberty", "persona", "economic"]).truth is TruthValue.TRUE)

# Sovereign denial
z3 = ZeroSystem(MockLattice(), MockAxiomGuard())
for l in (ZeroLevel.V1_PERCEPTION, ZeroLevel.V2_JUSTICE, ZeroLevel.V3_LIBERTY, ZeroLevel.V4_INTEGRATION):
    z3._levels_active[l] = True
seed3 = SeedActivation(z3, authorize=lambda: False)
ck("seed denied without sovereign auth", seed3.activate().truth is TruthValue.FALSE)

print("=" * 70)
total = passed + len(failed)
print(f"  {passed}/{total} passed")
if failed:
    for f_ in failed: print(f"    FAILED: {f_}")
else:
    print("  ZERO SYSTEM + SEED ACTIVATION SOUND")
print("=" * 70)
import sys
sys.exit(0 if not failed else 1)
